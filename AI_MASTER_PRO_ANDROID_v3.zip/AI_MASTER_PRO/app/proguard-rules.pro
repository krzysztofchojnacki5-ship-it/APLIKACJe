# AI MASTER PRO ProGuard rules
-keep class com.aimasterpro.** { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**
