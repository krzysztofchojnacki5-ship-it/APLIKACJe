package com.aimasterpro

import android.app.Application
import com.aimasterpro.data.local.AppDatabase
import com.aimasterpro.data.repository.*
import com.aimasterpro.domain.agent.Orchestrator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AIMasterApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var database: AppDatabase
        private set

    lateinit var taskRepository: TaskRepository
        private set
    lateinit var chatRepository: ChatRepository
        private set
    lateinit var memoryRepository: MemoryRepository
        private set
    lateinit var providerRepository: ProviderRepository
        private set
    lateinit var roleRepository: RoleRepository
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var backupRepository: BackupRepository
        private set
    lateinit var orchestrator: Orchestrator
        private set

    override fun onCreate() {
        super.onCreate()
        // getInstance() robi kopię bazy przed aktualizacją i stosuje migracje (bez kasowania danych)
        database = AppDatabase.getInstance(this)

        taskRepository = TaskRepository(database.taskDao(), database.agentResultDao(), database.agentMessageDao())
        chatRepository = ChatRepository(database.chatMessageDao(), database.conversationDao(), taskRepository)
        memoryRepository = MemoryRepository(database.memoryDao())
        providerRepository = ProviderRepository(database.aiProviderDao(), database.settingDao())
        roleRepository = RoleRepository(database.settingDao())
        settingsRepository = SettingsRepository(database.settingDao())
        backupRepository = BackupRepository(database.aiProviderDao(), database.settingDao(), database.memoryDao())

        orchestrator = Orchestrator(
            taskDao = database.taskDao(),
            agentResultDao = database.agentResultDao(),
            chatDao = database.chatMessageDao(),
            conversationDao = database.conversationDao(),
            agentMessageDao = database.agentMessageDao(),
            memoryDao = database.memoryDao(),
            providerDao = database.aiProviderDao(),
            settingDao = database.settingDao()
        )

        // Dodaje brakujące presety (np. Claude) — nigdy nie nadpisuje istniejących kluczy.
        appScope.launch {
            providerRepository.ensurePresets()
        }
    }
}
