package com.aimasterpro.data.local

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.aimasterpro.data.model.*
import java.io.File

@Database(
    entities = [
        TaskEntity::class,
        AgentResultEntity::class,
        ChatMessageEntity::class,
        MemoryItemEntity::class,
        AiProviderEntity::class,
        SettingEntity::class,
        ConversationEntity::class,
        AgentMessageEntity::class
    ],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun agentResultDao(): AgentResultDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun aiProviderDao(): AiProviderDao
    abstract fun settingDao(): SettingDao
    abstract fun conversationDao(): ConversationDao
    abstract fun agentMessageDao(): AgentMessageDao

    companion object {
        const val DB_NAME = "ai_master_pro.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Migracja 1 -> 2. NIE USUWA ŻADNYCH DANYCH (klucze API, pamięć, zadania zostają).
         * Dodaje tylko: kolumnę conversationId, tabelę conversations i tabelę agent_messages.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN conversationId TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS conversations (" +
                        "id TEXT NOT NULL, title TEXT NOT NULL, " +
                        "createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, " +
                        "PRIMARY KEY(id))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS agent_messages (" +
                        "id TEXT NOT NULL, taskId TEXT NOT NULL, fromRole TEXT NOT NULL, " +
                        "toRole TEXT NOT NULL, content TEXT NOT NULL, modelLabel TEXT NOT NULL, " +
                        "createdAt INTEGER NOT NULL, PRIMARY KEY(id))"
                )

                // Stare wiadomości trafiają do jednej rozmowy "Poprzednie rozmowy".
                var count = 0
                db.query("SELECT COUNT(*) FROM chat_messages").use { c ->
                    if (c.moveToFirst()) count = c.getInt(0)
                }
                if (count > 0) {
                    val now = System.currentTimeMillis()
                    db.execSQL(
                        "INSERT INTO conversations (id, title, createdAt, updatedAt) " +
                            "VALUES ('legacy', 'Poprzednie rozmowy', $now, $now)"
                    )
                    db.execSQL("UPDATE chat_messages SET conversationId = 'legacy'")
                }
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: build(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun build(context: Context): AppDatabase {
            DatabaseSafety.backupBeforeUpgrade(context)
            return Room.databaseBuilder(context, AppDatabase::class.java, DB_NAME)
                .addMigrations(MIGRATION_1_2)
                .fallbackToDestructiveMigrationOnDowngrade()
                // CELOWO BRAK fallbackToDestructiveMigration() — to ono kasowało klucze przy aktualizacji.
                .build()
        }
    }
}

/**
 * Siatka bezpieczeństwa: przy pierwszym uruchomieniu nowej wersji aplikacji kopiuje plik bazy
 * (razem z kluczami API) do files/db_backup/. Gdyby cokolwiek poszło nie tak, dane da się odzyskać.
 */
object DatabaseSafety {
    fun backupBeforeUpgrade(context: Context) {
        try {
            val prefs = context.getSharedPreferences("db_safety", Context.MODE_PRIVATE)
            val code = PackageInfoCompat.getLongVersionCode(
                context.packageManager.getPackageInfo(context.packageName, 0)
            )
            if (prefs.getLong("last_backup_version", -1L) == code) return

            val dbFile = context.getDatabasePath(AppDatabase.DB_NAME)
            if (dbFile.exists() && dbFile.length() > 0) {
                val dir = File(context.filesDir, "db_backup").apply { mkdirs() }
                for (suffix in listOf("", "-wal", "-shm")) {
                    val src = File(dbFile.path + suffix)
                    val dst = File(dir, "${AppDatabase.DB_NAME}$suffix.bak")
                    if (src.exists()) src.copyTo(dst, overwrite = true) else dst.delete()
                }
            }
            prefs.edit().putLong("last_backup_version", code).apply()
        } catch (_: Exception) {
            // kopia zapasowa nie może blokować startu aplikacji
        }
    }
}
