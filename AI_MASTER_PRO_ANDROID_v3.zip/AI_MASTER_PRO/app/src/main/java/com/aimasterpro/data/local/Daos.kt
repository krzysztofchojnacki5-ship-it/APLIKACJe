package com.aimasterpro.data.local

import androidx.room.*
import com.aimasterpro.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: String): TaskEntity?

    @Query("SELECT * FROM tasks WHERE status IN ('RUNNING', 'PLANNING', 'PAUSED', 'WAITING_APPROVAL')")
    suspend fun getActive(): List<TaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    @Update
    suspend fun update(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM tasks")
    suspend fun deleteAll()
}

@Dao
interface AgentResultDao {
    @Query("SELECT * FROM agent_results WHERE taskId = :taskId ORDER BY createdAt ASC")
    fun observeByTask(taskId: String): Flow<List<AgentResultEntity>>

    @Query("SELECT * FROM agent_results WHERE taskId = :taskId ORDER BY createdAt ASC")
    suspend fun getByTask(taskId: String): List<AgentResultEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(result: AgentResultEntity)

    @Query("DELETE FROM agent_results WHERE taskId = :taskId")
    suspend fun deleteByTask(taskId: String)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE taskId = :taskId ORDER BY createdAt ASC")
    fun observeByTask(taskId: String): Flow<List<ChatMessageEntity>>

    /** Główny czat pokazuje tylko wiadomości użytkownika / MASTER / systemowe (bez rozmów agentów). */
    @Query("SELECT * FROM chat_messages WHERE conversationId = :cid AND role != 'AGENT' ORDER BY createdAt ASC")
    fun observeConversation(cid: String): Flow<List<ChatMessageEntity>>

    /** Najnowsze wiadomości rozmowy (malejąco) — kontekst dla MASTER. */
    @Query("SELECT * FROM chat_messages WHERE conversationId = :cid AND role IN ('USER','ASSISTANT') ORDER BY createdAt DESC LIMIT :limit")
    suspend fun recent(cid: String, limit: Int): List<ChatMessageEntity>

    @Query("SELECT DISTINCT taskId FROM chat_messages WHERE conversationId = :cid AND taskId IS NOT NULL")
    suspend fun taskIdsOf(cid: String): List<String>

    @Query("DELETE FROM chat_messages WHERE conversationId = :cid")
    suspend fun deleteByConversation(cid: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM chat_messages")
    suspend fun deleteAll()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory_items ORDER BY isPinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<MemoryItemEntity>>

    @Query("SELECT * FROM memory_items WHERE title LIKE '%' || :q || '%' OR content LIKE '%' || :q || '%' OR tags LIKE '%' || :q || '%'")
    suspend fun search(q: String): List<MemoryItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: MemoryItemEntity)

    @Query("DELETE FROM memory_items WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM memory_items")
    suspend fun deleteAll()
}

@Dao
interface AiProviderDao {
    @Query("SELECT * FROM ai_providers ORDER BY isDefault DESC, name ASC")
    fun observeAll(): Flow<List<AiProviderEntity>>

    @Query("SELECT * FROM ai_providers WHERE isEnabled = 1")
    suspend fun getEnabled(): List<AiProviderEntity>

    @Query("SELECT * FROM ai_providers ORDER BY isDefault DESC, name ASC")
    suspend fun getAll(): List<AiProviderEntity>

    @Query("SELECT COUNT(*) FROM ai_providers")
    suspend fun count(): Int

    @Query("SELECT * FROM ai_providers WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefault(): AiProviderEntity?

    @Query("SELECT * FROM ai_providers WHERE id = :id")
    suspend fun getById(id: String): AiProviderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(provider: AiProviderEntity)

    @Query("UPDATE ai_providers SET isDefault = 0")
    suspend fun clearDefaults()

    @Query("DELETE FROM ai_providers WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface SettingDao {
    @Query("SELECT * FROM settings WHERE `key` = :key")
    suspend fun get(key: String): SettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(setting: SettingEntity)

    @Query("SELECT * FROM settings")
    suspend fun getAll(): List<SettingEntity>

    @Query("SELECT * FROM settings")
    fun observeAll(): Flow<List<SettingEntity>>
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun getById(id: String): ConversationEntity?

    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getLatest(): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(conversation: ConversationEntity)

    @Query("UPDATE conversations SET updatedAt = :time WHERE id = :id")
    suspend fun touch(id: String, time: Long)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface AgentMessageDao {
    @Query("SELECT * FROM agent_messages WHERE taskId = :taskId ORDER BY createdAt ASC")
    fun observeByTask(taskId: String): Flow<List<AgentMessageEntity>>

    @Query("SELECT DISTINCT taskId FROM agent_messages")
    fun observeTaskIds(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: AgentMessageEntity)

    @Query("DELETE FROM agent_messages WHERE taskId = :taskId")
    suspend fun deleteByTask(taskId: String)
}
