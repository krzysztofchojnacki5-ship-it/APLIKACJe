package com.aimasterpro.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

// ==================== ENUMS ====================

enum class TaskStatus {
    PENDING, PLANNING, RUNNING, WAITING_APPROVAL, COMPLETED, FAILED, CANCELLED, PAUSED
}

enum class AgentRole {
    MASTER, RESEARCHER, PROGRAMMER, AUDITOR, TESTER, PLANNER, FILE_SPECIALIST, SUMMARIZER
}

enum class AgentStatus {
    IDLE, WORKING, WAITING, DONE, ERROR
}

enum class MessageRole {
    USER, ASSISTANT, SYSTEM, AGENT
}

enum class ProviderType {
    OPENAI_COMPATIBLE, GROQ, OPENROUTER, CUSTOM, LOCAL_STUB, ANTHROPIC, GEMINI
}

// ==================== ROOM ENTITIES ====================

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val userCommand: String,
    val status: String, // TaskStatus
    val planJson: String = "[]",
    val currentStep: Int = 0,
    val maxIterations: Int = 10,
    val iterationCount: Int = 0,
    val result: String = "",
    val errorLog: String = "",
    val modelId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

@Entity(tableName = "agent_results")
data class AgentResultEntity(
    @PrimaryKey val id: String,
    val taskId: String,
    val agentRole: String,
    val input: String,
    val output: String,
    val status: String,
    val errorMessage: String = "",
    val iteration: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val taskId: String? = null,
    val role: String, // MessageRole
    val content: String,
    val agentRole: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    // v2: przynależność do rozmowy (historia czatów jak w ChatGPT)
    @ColumnInfo(defaultValue = "''") val conversationId: String = ""
)

/** v2: lista rozmów (panel historii czatów). */
@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/** v2: prywatna rozmowa agentów (MASTER <-> specjaliści), ukryta dopóki użytkownik jej nie otworzy. */
@Entity(tableName = "agent_messages")
data class AgentMessageEntity(
    @PrimaryKey val id: String,
    val taskId: String,
    val fromRole: String,
    val toRole: String,
    val content: String,
    val modelLabel: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "memory_items")
data class MemoryItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val tags: String = "", // comma-separated
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_providers")
data class AiProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // ProviderType
    val baseUrl: String,
    val apiKeyEncrypted: String = "",
    val modelName: String = "",
    val isEnabled: Boolean = true,
    val isDefault: Boolean = false,
    val maxTokens: Int = 4096,
    val temperature: Float = 0.7f,
    val extraHeadersJson: String = "{}",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)

// ==================== DOMAIN MODELS ====================

data class TaskPlanStep(
    val id: String,
    val order: Int,
    val agentRole: AgentRole,
    val description: String,
    val status: TaskStatus = TaskStatus.PENDING,
    val dependsOn: List<String> = emptyList(),
    val result: String = ""
)

data class AgentTask(
    val id: String,
    val taskId: String,
    val role: AgentRole,
    val instruction: String,
    val context: String,
    val status: AgentStatus = AgentStatus.IDLE,
    val result: String = "",
    val error: String = ""
)

data class ChatMessage(
    val id: String,
    val role: MessageRole,
    val content: String,
    val agentRole: AgentRole? = null,
    val taskId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val conversationId: String = ""
)

data class Conversation(
    val id: String,
    val title: String,
    val updatedAt: Long
)

data class AgentMessage(
    val id: String,
    val taskId: String,
    val from: String,
    val to: String,
    val content: String,
    val modelLabel: String,
    val timestamp: Long
)

data class MemoryItem(
    val id: String,
    val title: String,
    val content: String,
    val tags: List<String> = emptyList(),
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class AiProviderConfig(
    val id: String,
    val name: String,
    val type: ProviderType,
    val baseUrl: String,
    val apiKey: String = "",
    val modelName: String = "",
    val isEnabled: Boolean = true,
    val isDefault: Boolean = false,
    val maxTokens: Int = 4096,
    val temperature: Float = 0.7f
)

/** Model można użyć, gdy jest włączony i ma klucz (lokalny/własny endpoint może działać bez klucza). */
val AiProviderConfig.isUsable: Boolean
    get() = isEnabled && (type == ProviderType.LOCAL_STUB || type == ProviderType.CUSTOM || apiKey.isNotBlank())

data class LlmRequest(
    val messages: List<LlmMessage>,
    val model: String,
    val maxTokens: Int = 4096,
    val temperature: Float = 0.7f,
    val stream: Boolean = false
)

data class LlmMessage(
    val role: String, // system, user, assistant
    val content: String
)

data class LlmResponse(
    val content: String,
    val model: String = "",
    val finishReason: String = "",
    val usageTokens: Int = 0,
    val error: String? = null
)

data class AppSettings(
    val maxIterations: Int = 8,
    val requestTimeoutSec: Int = 90,
    val autoSaveMemory: Boolean = false,
    val language: String = "pl",
    val requireApprovalForDestructive: Boolean = true,
    val defaultModelId: String = ""
)

// ==================== CONVERTERS ====================

class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromStringList(value: List<String>): String = gson.toJson(value)

    @TypeConverter
    fun toStringList(value: String): List<String> {
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }
}
