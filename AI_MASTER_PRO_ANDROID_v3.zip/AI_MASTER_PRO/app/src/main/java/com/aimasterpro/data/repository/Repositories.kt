package com.aimasterpro.data.repository

import com.aimasterpro.data.local.*
import com.aimasterpro.data.model.*
import com.aimasterpro.domain.provider.ProviderFactory
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class TaskRepository(
    private val dao: TaskDao,
    private val agentDao: AgentResultDao,
    private val agentMessageDao: AgentMessageDao
) {
    fun observeTasks(): Flow<List<TaskEntity>> = dao.observeAll()
    suspend fun getTask(id: String) = dao.getById(id)
    suspend fun deleteTask(id: String) {
        agentDao.deleteByTask(id)
        agentMessageDao.deleteByTask(id)
        dao.delete(id)
    }

    fun observeAgentResults(taskId: String) = agentDao.observeByTask(taskId)
    suspend fun getAgentResults(taskId: String) = agentDao.getByTask(taskId)

    fun observeAgentMessages(taskId: String): Flow<List<AgentMessage>> =
        agentMessageDao.observeByTask(taskId).map { list ->
            list.map {
                AgentMessage(
                    id = it.id,
                    taskId = it.taskId,
                    from = it.fromRole,
                    to = it.toRole,
                    content = it.content,
                    modelLabel = it.modelLabel,
                    timestamp = it.createdAt
                )
            }
        }

    fun observeTaskIdsWithAgentChat(): Flow<Set<String>> =
        agentMessageDao.observeTaskIds().map { it.toSet() }
}

class ChatRepository(
    private val dao: ChatMessageDao,
    private val conversationDao: ConversationDao,
    private val taskRepository: TaskRepository
) {
    private fun ChatMessageEntity.toDomain() = ChatMessage(
        id = id,
        role = try { MessageRole.valueOf(role) } catch (_: Exception) { MessageRole.SYSTEM },
        content = content,
        agentRole = agentRole?.let { r -> try { AgentRole.valueOf(r) } catch (_: Exception) { null } },
        taskId = taskId,
        timestamp = createdAt,
        conversationId = conversationId
    )

    fun observeConversation(conversationId: String): Flow<List<ChatMessage>> =
        dao.observeConversation(conversationId).map { list -> list.map { it.toDomain() } }

    fun observeConversations(): Flow<List<Conversation>> =
        conversationDao.observeAll().map { list ->
            list.map { Conversation(it.id, it.title, it.updatedAt) }
        }

    suspend fun latestConversationId(): String? = conversationDao.getLatest()?.id
    suspend fun conversationExists(id: String): Boolean = conversationDao.getById(id) != null

    /** Usuwa rozmowę razem z zadaniami i prywatnymi rozmowami agentów, które do niej należały. */
    suspend fun deleteConversation(id: String) {
        dao.taskIdsOf(id).forEach { taskRepository.deleteTask(it) }
        dao.deleteByConversation(id)
        conversationDao.delete(id)
    }

    suspend fun deleteMessages(ids: List<String>) = ids.forEach { dao.delete(it) }

    suspend fun clearAll() = dao.deleteAll()
}

class MemoryRepository(private val dao: MemoryDao) {
    fun observeAll(): Flow<List<MemoryItem>> = dao.observeAll().map { list ->
        list.map {
            MemoryItem(
                id = it.id,
                title = it.title,
                content = it.content,
                tags = it.tags.split(",").map { t -> t.trim() }.filter { t -> t.isNotEmpty() },
                isPinned = it.isPinned,
                createdAt = it.createdAt
            )
        }
    }

    suspend fun save(title: String, content: String, tags: List<String> = emptyList(), id: String? = null) {
        val itemId = id ?: UUID.randomUUID().toString()
        dao.upsert(
            MemoryItemEntity(
                id = itemId,
                title = title,
                content = content,
                tags = tags.joinToString(","),
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun delete(id: String) = dao.delete(id)
    suspend fun clearAll() = dao.deleteAll()
    suspend fun search(q: String) = dao.search(q)
}

class ProviderRepository(
    private val dao: AiProviderDao,
    private val settingDao: SettingDao
) {
    fun observeProviders(): Flow<List<AiProviderConfig>> = dao.observeAll().map { list ->
        list.map { it.toConfig() }
    }

    suspend fun getAll() = dao.getAll().map { it.toConfig() }
    suspend fun getEnabled() = dao.getEnabled().map { it.toConfig() }
    suspend fun getDefault() = dao.getDefault()?.toConfig()

    suspend fun save(config: AiProviderConfig) {
        if (config.isDefault) dao.clearDefaults()
        // Zachowujemy dodatkowe nagłówki zapisane wcześniej (nie nadpisujemy ich pustymi).
        val old = dao.getById(config.id)
        dao.upsert(
            AiProviderEntity(
                id = config.id,
                name = config.name,
                type = config.type.name,
                baseUrl = config.baseUrl,
                apiKeyEncrypted = config.apiKey,
                modelName = config.modelName,
                isEnabled = config.isEnabled,
                isDefault = config.isDefault,
                maxTokens = config.maxTokens,
                temperature = config.temperature,
                extraHeadersJson = old?.extraHeadersJson ?: "{}",
                createdAt = old?.createdAt ?: System.currentTimeMillis()
            )
        )
    }

    suspend fun delete(id: String) {
        dao.delete(id)
        // przypisania ról wskazujące na usunięty model znikają (rola wraca do MASTER)
        settingDao.getAll()
            .filter { it.key.startsWith(RoleRepository.PREFIX) && it.value == id }
            .forEach { settingDao.upsert(SettingEntity(it.key, "")) }
    }

    /**
     * Presety dodajemy tylko, gdy ich brakuje — nigdy nie nadpisujemy istniejących kluczy.
     * Użytkownikom po aktualizacji dochodzą nowe presety (Claude, Gemini, Perplexity).
     */
    suspend fun ensurePresets() {
        val seeded = settingDao.get(SEEDED_KEY)?.value == "1"
        if (dao.count() == 0) {
            ProviderFactory.presets().forEach { save(it) }
        } else if (!seeded) {
            ProviderFactory.presets()
                .filter { it.id in NEW_IN_V2 && dao.getById(it.id) == null }
                .forEach { save(it) }
        }
        if (!seeded) settingDao.upsert(SettingEntity(SEEDED_KEY, "1"))
    }

    private fun AiProviderEntity.toConfig() = AiProviderConfig(
        id = id,
        name = name,
        type = try { ProviderType.valueOf(type) } catch (_: Exception) { ProviderType.CUSTOM },
        baseUrl = baseUrl,
        apiKey = apiKeyEncrypted,
        modelName = modelName,
        isEnabled = isEnabled,
        isDefault = isDefault,
        maxTokens = maxTokens,
        temperature = temperature
    )

    companion object {
        private const val SEEDED_KEY = "presets_seeded_v2"
        private val NEW_IN_V2 = setOf("anthropic", "gemini", "perplexity")
    }
}

/** Przypisanie: rola agenta -> model (zapisywane w tabeli settings, bez zmian schematu bazy). */
class RoleRepository(private val settingDao: SettingDao) {
    fun observeAssignments(): Flow<Map<AgentRole, String>> =
        settingDao.observeAll().map { list -> parse(list) }

    suspend fun getAssignments(): Map<AgentRole, String> = parse(settingDao.getAll())

    suspend fun assign(role: AgentRole, providerId: String?) {
        settingDao.upsert(SettingEntity(PREFIX + role.name, providerId ?: ""))
    }

    private fun parse(list: List<SettingEntity>): Map<AgentRole, String> {
        val out = mutableMapOf<AgentRole, String>()
        for (s in list) {
            if (!s.key.startsWith(PREFIX) || s.value.isBlank()) continue
            val role = try { AgentRole.valueOf(s.key.removePrefix(PREFIX)) } catch (_: Exception) { null }
            if (role != null) out[role] = s.value
        }
        return out
    }

    companion object {
        const val PREFIX = "role_provider_"
    }
}

class SettingsRepository(private val dao: SettingDao) {
    suspend fun get(key: String, default: String = ""): String =
        dao.get(key)?.value ?: default

    suspend fun set(key: String, value: String) =
        dao.upsert(SettingEntity(key, value))

    suspend fun getAppSettings(): AppSettings = AppSettings(
        maxIterations = get("max_iterations", "8").toIntOrNull() ?: 8,
        requestTimeoutSec = get("timeout_sec", "90").toIntOrNull() ?: 90,
        autoSaveMemory = get("auto_save_memory", "false").toBoolean(),
        language = get("language", "pl"),
        requireApprovalForDestructive = get("require_approval", "true").toBoolean(),
        defaultModelId = get("default_model_id", "")
    )

    suspend fun saveAppSettings(s: AppSettings) {
        set("max_iterations", s.maxIterations.toString())
        set("timeout_sec", s.requestTimeoutSec.toString())
        set("auto_save_memory", s.autoSaveMemory.toString())
        set("language", s.language)
        set("require_approval", s.requireApprovalForDestructive.toString())
        set("default_model_id", s.defaultModelId)
    }
}

/** Eksport / import konfiguracji (modele + klucze + role + pamięć) do pliku JSON. */
class BackupRepository(
    private val providerDao: AiProviderDao,
    private val settingDao: SettingDao,
    private val memoryDao: MemoryDao
) {
    private class BackupFile(
        val format: String?,
        val version: Int,
        val exportedAt: Long,
        val providers: List<AiProviderEntity>?,
        val settings: List<SettingEntity>?,
        val memory: List<MemoryItemEntity>?
    )

    private val gson = Gson()

    suspend fun export(): String {
        val file = BackupFile(
            format = FORMAT,
            version = 2,
            exportedAt = System.currentTimeMillis(),
            providers = providerDao.getAll(),
            settings = settingDao.getAll(),
            memory = memoryDao.search("")
        )
        return gson.toJson(file)
    }

    /** Zwraca krótkie podsumowanie lub rzuca wyjątek, gdy plik jest nieprawidłowy. */
    suspend fun restore(json: String): String {
        val file = gson.fromJson(json, BackupFile::class.java)
        require(file != null && file.format == FORMAT) { "To nie jest plik kopii AI Master Pro." }
        val providers = file.providers.orEmpty()
        val settings = file.settings.orEmpty()
        val memory = file.memory.orEmpty()
        providers.forEach { providerDao.upsert(it) }
        settings.forEach { settingDao.upsert(it) }
        memory.forEach { memoryDao.upsert(it) }
        return "Przywrócono: modele ${providers.size}, ustawienia ${settings.size}, pamięć ${memory.size}."
    }

    companion object {
        const val FORMAT = "ai_master_pro_backup"
    }
}
