package com.aimasterpro.domain.agent

import com.aimasterpro.data.local.*
import com.aimasterpro.data.model.*
import com.aimasterpro.data.repository.RoleRepository
import com.aimasterpro.domain.provider.LlmProvider
import com.aimasterpro.domain.provider.ProviderFactory
import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Koordynator wieloagentowy.
 *
 * Przepływ jednej wiadomości:
 *  1. MASTER dostaje historię rozmowy i odpowiada użytkownikowi strumieniowo (jak ChatGPT).
 *  2. Jeśli zadanie jest złożone, MASTER zamiast odpowiedzi zwraca plan (@@DELEGATE@@{...}).
 *  3. Specjaliści (każdy na własnym modelu) wykonują kroki; rozmowa MASTER <-> agent zapisywana jest
 *     w tabeli agent_messages i jest ukryta, dopóki użytkownik jej nie otworzy.
 *  4. AUDITOR ocenia wyniki (max. jedna runda poprawek).
 *  5. MASTER składa odpowiedź końcową i pokazuje ją użytkownikowi.
 */
class Orchestrator(
    private val taskDao: TaskDao,
    private val agentResultDao: AgentResultDao,
    private val chatDao: ChatMessageDao,
    private val conversationDao: ConversationDao,
    private val agentMessageDao: AgentMessageDao,
    private val memoryDao: MemoryDao,
    private val providerDao: AiProviderDao,
    private val settingDao: SettingDao
) {
    private val gson = Gson()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _activeTaskId = MutableStateFlow<String?>(null)
    val activeTaskId: StateFlow<String?> = _activeTaskId.asStateFlow()

    private val _progressLog = MutableStateFlow<List<String>>(emptyList())
    val progressLog: StateFlow<List<String>> = _progressLog.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _runningConversationId = MutableStateFlow<String?>(null)
    val runningConversationId: StateFlow<String?> = _runningConversationId.asStateFlow()

    /** Tekst odpowiedzi MASTER w trakcie pisania (streaming). */
    private val _streamingText = MutableStateFlow("")
    val streamingText: StateFlow<String> = _streamingText.asStateFlow()

    /** Krótki status typu "Programista pracuje…". */
    private val _statusText = MutableStateFlow("")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _activeRole = MutableStateFlow<AgentRole?>(null)
    val activeRole: StateFlow<AgentRole?> = _activeRole.asStateFlow()

    private var currentJob: Job? = null
    private var currentTaskId: String? = null

    private fun log(msg: String) {
        _progressLog.value = (_progressLog.value + msg).takeLast(200)
    }

    private fun setStatus(s: String) {
        _statusText.value = s
    }

    // -------------------- PUBLIC API --------------------

    fun sendMessage(conversationId: String, text: String, addUserMessage: Boolean = true) {
        val userText = text.trim()
        if (userText.isBlank() || _isRunning.value) return
        _isRunning.value = true
        _runningConversationId.value = conversationId
        _streamingText.value = ""
        _progressLog.value = emptyList()
        currentTaskId = null

        currentJob = scope.launch {
            try {
                runTurn(conversationId, userText, addUserMessage)
            } catch (e: CancellationException) {
                withContext(NonCancellable) { handleCancelled(conversationId) }
            } catch (e: Exception) {
                withContext(NonCancellable) {
                    log("Błąd krytyczny: ${e.message}")
                    addChat(MessageRole.SYSTEM, "⚠️ Wystąpił błąd: ${e.message ?: e.javaClass.simpleName}", conversationId)
                    currentTaskId?.let { updateTaskStatus(it, TaskStatus.FAILED, error = e.message ?: "") }
                }
            } finally {
                _isRunning.value = false
                _runningConversationId.value = null
                _activeTaskId.value = null
                _activeRole.value = null
                _streamingText.value = ""
                _statusText.value = ""
                currentTaskId = null
            }
        }
    }

    fun cancel() {
        log("Żądanie anulowania…")
        currentJob?.cancel()
    }

    // -------------------- PIPELINE --------------------

    private class AppCfg(val maxIterations: Int, val timeoutSec: Int)

    private class Report(val role: AgentRole, val text: String, val failed: Boolean)

    private class AgentOutcome(val text: String, val failed: Boolean, val label: String)

    private class Team(
        val providers: List<AiProviderConfig>,
        val assignments: Map<AgentRole, String>,
        private val timeoutSec: Int,
        private val onFixed: (AiProviderConfig, String) -> Unit
    ) {
        private val cache = mutableMapOf<String, LlmProvider>()
        val masterConfig: AiProviderConfig = TeamResolver.master(providers)

        fun configFor(role: AgentRole) = TeamResolver.forRole(role, providers, assignments)
        fun obtain(c: AiProviderConfig): LlmProvider = cache.getOrPut(c.id) { ProviderFactory.create(c, timeoutSec, true, onFixed) }
        fun providerFor(role: AgentRole): LlmProvider = obtain(configFor(role))
        fun label(c: AiProviderConfig) = "${c.name} · ${c.modelName}"

        fun describe(): String {
            val roles = listOf(
                AgentRole.PLANNER, AgentRole.RESEARCHER, AgentRole.PROGRAMMER,
                AgentRole.TESTER, AgentRole.FILE_SPECIALIST, AgentRole.SUMMARIZER
            )
            val lines = roles.map { r ->
                "- ${r.name} (${AgentPrompts.roleDisplayName(r)}): ${AgentPrompts.roleDescription(r)}"
            }
            return lines.joinToString("\n") +
                "\n- AUDITOR (Audytor): sprawdza wyniki — dodawany automatycznie po pracy zespołu"
        }
    }

    private suspend fun runTurn(cid: String, userText: String, addUserMessage: Boolean) {
        val cfg = loadAppCfg()
        ensureConversation(cid, userText)
        if (addUserMessage) addChat(MessageRole.USER, userText, cid)
        log("Nowa wiadomość od użytkownika.")

        val team = loadTeam(cfg.timeoutSec)
        val masterCfg = team.masterConfig
        val master = team.obtain(masterCfg)
        val date = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("pl", "PL")).format(Date())
        val memory = memoryContext(userText)
        val history = buildHistory(cid)
        val allowDelegate = TeamResolver.hasRealModel(team.providers)

        _activeRole.value = AgentRole.MASTER
        setStatus("Myślę…")

        val system = AgentPrompts.masterChatPrompt(team.describe(), memory, date, allowDelegate)
        val messages = listOf(LlmMessage("system", system)) + history

        val marker = AgentPrompts.DELEGATE_MARKER
        val buf = StringBuilder()
        var mode = 0 // 0 = jeszcze nie wiadomo, 1 = odpowiedź bezpośrednia, 2 = delegacja
        val resp = master.chatStream(request(masterCfg, messages)) { delta ->
            buf.append(delta)
            if (mode == 0) {
                val head = buf.toString().trimStart()
                if (head.length >= marker.length || !marker.startsWith(head)) {
                    mode = if (head.startsWith(marker)) 2 else 1
                    if (mode == 2) setStatus("MASTER przygotowuje plan dla zespołu…")
                }
            }
            if (mode == 1) _streamingText.value = buf.toString()
        }

        val text = buf.toString().trim()
        if (resp.error != null && text.isBlank()) {
            log("Błąd MASTER: ${resp.error}")
            addChat(MessageRole.SYSTEM, "⚠️ Nie udało się uzyskać odpowiedzi od modelu ${masterCfg.name}: ${resp.error}", cid)
            return
        }

        if (mode == 2) {
            val steps = parsePlan(text.substringAfter(marker))
            if (steps.isNotEmpty()) {
                runTeam(cid, userText, history, steps, team, cfg, memory, date)
                return
            }
            // plan nieczytelny — MASTER odpowiada sam
            log("Plan nieczytelny — MASTER odpowiada samodzielnie.")
            answerWithoutTeam(cid, master, masterCfg, history, memory, date)
            return
        }

        addChat(MessageRole.ASSISTANT, text, cid, AgentRole.MASTER)
        conversationDao.touch(cid, System.currentTimeMillis())
        log("MASTER odpowiedział bezpośrednio.")
    }

    private suspend fun answerWithoutTeam(
        cid: String,
        master: LlmProvider,
        masterCfg: AiProviderConfig,
        history: List<LlmMessage>,
        memory: String,
        date: String
    ) {
        val system = AgentPrompts.masterChatPrompt("", memory, date, false)
        val buf = StringBuilder()
        val resp = master.chatStream(request(masterCfg, listOf(LlmMessage("system", system)) + history)) {
            buf.append(it)
            _streamingText.value = buf.toString()
        }
        val text = buf.toString().trim()
        if (text.isBlank()) {
            addChat(MessageRole.SYSTEM, "⚠️ Brak odpowiedzi modelu: ${resp.error ?: "pusta odpowiedź"}", cid)
        } else {
            addChat(MessageRole.ASSISTANT, text, cid, AgentRole.MASTER)
        }
    }

    private suspend fun runTeam(
        cid: String,
        userText: String,
        history: List<LlmMessage>,
        steps: List<TaskPlanStep>,
        team: Team,
        cfg: AppCfg,
        memory: String,
        date: String
    ) {
        val masterCfg = team.masterConfig
        val masterLabel = team.label(masterCfg)
        val taskId = UUID.randomUUID().toString()
        currentTaskId = taskId
        _activeTaskId.value = taskId

        taskDao.upsert(
            TaskEntity(
                id = taskId,
                title = userText.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(60) ?: "Zadanie",
                userCommand = userText,
                status = TaskStatus.RUNNING.name,
                planJson = gson.toJson(steps),
                maxIterations = cfg.maxIterations,
                modelId = masterCfg.modelName
            )
        )
        log("Plan: ${steps.size} kroków.")

        val context = condensedHistory(history)
        val reports = mutableListOf<Report>()
        var calls = 0

        for (step in steps) {
            if (calls >= cfg.maxIterations) {
                log("Osiągnięto limit kroków (${cfg.maxIterations}).")
                break
            }
            calls++
            updateTaskStatus(taskId, TaskStatus.RUNNING, currentStep = step.order)

            postAgentMessage(taskId, AgentRole.MASTER.name, step.agentRole.name, step.description, masterLabel)
            val brief = buildBrief(userText, context, step, reports)
            val out = runAgent(step.agentRole, brief, team, taskId, calls)
            reports.add(Report(step.agentRole, out.text, out.failed))
            postAgentMessage(taskId, step.agentRole.name, AgentRole.MASTER.name, out.text, out.label)
        }

        // --- Audyt (+ maks. jedna runda poprawek) ---
        var auditText = ""
        if (reports.any { !it.failed }) {
            postAgentMessage(
                taskId, AgentRole.MASTER.name, AgentRole.AUDITOR.name,
                "Oceń wyniki zespołu względem polecenia użytkownika.", masterLabel
            )
            val audit = runAgent(AgentRole.AUDITOR, buildAuditBrief(userText, reports), team, taskId, ++calls)
            postAgentMessage(taskId, AgentRole.AUDITOR.name, AgentRole.MASTER.name, audit.text, audit.label)

            if (!audit.failed) {
                auditText = audit.text
                val needsFix = audit.text.trimStart().take(40).uppercase().contains("WYMAGA_POPRAWY")
                val target = reports.lastOrNull {
                    !it.failed && it.role != AgentRole.AUDITOR && it.role != AgentRole.TESTER && it.role != AgentRole.SUMMARIZER
                }
                if (needsFix && target != null) {
                    val fixInstruction = "Audytor zgłosił uwagi do Twojej pracy. Popraw wynik i zwróć jego pełną, poprawioną wersję.\n\nUwagi audytora:\n${audit.text.take(4000)}"
                    postAgentMessage(taskId, AgentRole.MASTER.name, target.role.name, fixInstruction, masterLabel)
                    val fixBrief = buildString {
                        append("Oryginalne polecenie użytkownika:\n$userText\n\n")
                        append("Twoja poprzednia wersja:\n${target.text.take(6000)}\n\n")
                        append(fixInstruction)
                    }
                    val fix = runAgent(target.role, fixBrief, team, taskId, ++calls)
                    postAgentMessage(taskId, target.role.name, AgentRole.MASTER.name, fix.text, fix.label)
                    if (!fix.failed) reports.add(Report(target.role, "POPRAWIONA WERSJA:\n" + fix.text, false))
                }
            }
        }

        // --- Odpowiedź końcowa MASTER (streaming) ---
        _activeRole.value = AgentRole.MASTER
        setStatus("MASTER pisze odpowiedź…")
        log("MASTER składa odpowiedź końcową.")

        val pack = buildFinalPack(userText, reports, auditText)
        val finalMessages = listOf(LlmMessage("system", AgentPrompts.masterFinalPrompt(date, memory))) +
            history.dropLast(1) + LlmMessage("user", pack)
        val buf = StringBuilder()
        val resp = team.obtain(masterCfg).chatStream(request(masterCfg, finalMessages)) {
            buf.append(it)
            _streamingText.value = buf.toString()
        }
        var finalText = buf.toString().trim()
        if (finalText.isBlank()) {
            log("MASTER nie złożył odpowiedzi (${resp.error}) — pokazuję surowe raporty.")
            finalText = reports.joinToString("\n\n") {
                "**${AgentPrompts.roleDisplayName(it.role)}**\n${it.text}"
            }.ifBlank { "Nie udało się uzyskać wyniku od zespołu." }
        }

        val allFailed = reports.none { !it.failed }
        updateTaskStatus(
            taskId,
            if (allFailed) TaskStatus.FAILED else TaskStatus.COMPLETED,
            result = finalText
        )
        addChat(MessageRole.ASSISTANT, finalText, cid, AgentRole.MASTER, taskId)
        conversationDao.touch(cid, System.currentTimeMillis())
        log("Zadanie zakończone.")
    }

    private suspend fun runAgent(
        role: AgentRole,
        userContent: String,
        team: Team,
        taskId: String,
        iteration: Int
    ): AgentOutcome {
        val name = AgentPrompts.roleDisplayName(role)
        var cfg = team.configFor(role)
        _activeRole.value = role
        setStatus("$name pracuje…")
        log("$name (${cfg.name}) rozpoczyna pracę.")

        val messages = listOf(
            LlmMessage("system", AgentPrompts.agentSystem(role)),
            LlmMessage("user", userContent)
        )
        val temp = when (role) {
            AgentRole.PROGRAMMER, AgentRole.AUDITOR, AgentRole.TESTER -> minOf(cfg.temperature, 0.3f)
            else -> cfg.temperature
        }

        var resp = team.obtain(cfg).chat(request(cfg, messages, temp))
        if (resp.error != null && cfg.id != team.masterConfig.id) {
            log("Model ${cfg.name} zawiódł (${resp.error}) — zadanie przejmuje MASTER.")
            cfg = team.masterConfig
            resp = team.obtain(cfg).chat(request(cfg, messages, temp))
        }

        val failed = resp.error != null || resp.content.isBlank()
        val text = when {
            resp.error != null -> "BŁĄD: ${resp.error}"
            resp.content.isBlank() -> "BŁĄD: model zwrócił pustą odpowiedź."
            else -> resp.content
        }

        agentResultDao.insert(
            AgentResultEntity(
                id = UUID.randomUUID().toString(),
                taskId = taskId,
                agentRole = role.name,
                input = userContent.take(2000),
                output = text,
                status = if (failed) AgentStatus.ERROR.name else AgentStatus.DONE.name,
                errorMessage = resp.error ?: "",
                iteration = iteration
            )
        )
        log(if (failed) "$name: błąd — ${resp.error ?: "pusta odpowiedź"}" else "$name zakończył pracę.")
        return AgentOutcome(text, failed, team.label(cfg))
    }

    // -------------------- BRIEFY --------------------

    private fun buildBrief(userText: String, context: String, step: TaskPlanStep, prev: List<Report>): String =
        buildString {
            append("Oryginalne polecenie użytkownika:\n$userText\n\n")
            if (context.isNotBlank()) append("Kontekst wcześniejszej rozmowy:\n$context\n\n")
            append("Twoje zadanie od MASTER (krok ${step.order}):\n${step.description}\n")
            if (prev.isNotEmpty()) {
                append("\nWyniki poprzednich agentów:\n")
                prev.forEach {
                    append("--- ${AgentPrompts.roleDisplayName(it.role)} ---\n${it.text.take(6000)}\n\n")
                }
            }
        }

    private fun buildAuditBrief(userText: String, reports: List<Report>): String = buildString {
        append("Oryginalne polecenie użytkownika:\n$userText\n\nWyniki agentów do oceny:\n")
        reports.forEach { append("--- ${AgentPrompts.roleDisplayName(it.role)} ---\n${it.text.take(6000)}\n\n") }
        append("Pamiętaj: pierwsza linia odpowiedzi to dokładnie OK albo WYMAGA_POPRAWY.")
    }

    private fun buildFinalPack(userText: String, reports: List<Report>, audit: String): String = buildString {
        append("Wiadomość użytkownika:\n$userText\n\n")
        append("RAPORTY ZESPOŁU (wewnętrzne, nie cytuj ich dosłownie):\n")
        reports.forEach { append("=== ${AgentPrompts.roleDisplayName(it.role)} ===\n${it.text.take(8000)}\n\n") }
        if (audit.isNotBlank()) append("=== AUDYTOR ===\n${audit.take(3000)}\n\n")
        append("Napisz teraz końcową odpowiedź dla użytkownika.")
    }

    private fun condensedHistory(history: List<LlmMessage>): String =
        history.dropLast(1).takeLast(6).joinToString("\n") {
            (if (it.role == "user") "Użytkownik: " else "Asystent: ") + it.content.take(600)
        }

    // -------------------- HELPERS --------------------

    private fun request(cfg: AiProviderConfig, messages: List<LlmMessage>, temperature: Float = cfg.temperature) =
        LlmRequest(
            messages = messages,
            model = cfg.modelName,
            maxTokens = cfg.maxTokens,
            temperature = temperature
        )

    private suspend fun buildHistory(cid: String): List<LlmMessage> {
        val recent = chatDao.recent(cid, 30) // od najnowszej
        var budget = 24_000
        val picked = ArrayList<LlmMessage>()
        for (m in recent) {
            val content = m.content.take(12_000)
            if (picked.isNotEmpty() && budget - content.length < 0) break
            budget -= content.length
            picked.add(0, LlmMessage(if (m.role == MessageRole.USER.name) "user" else "assistant", content))
        }
        return picked
    }

    private suspend fun memoryContext(text: String): String {
        val words = text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 5 }.distinct().take(4)
        if (words.isEmpty()) return ""
        val found = LinkedHashMap<String, MemoryItemEntity>()
        for (w in words) memoryDao.search(w).forEach { found.putIfAbsent(it.id, it) }
        val top = found.values.take(4)
        if (top.isEmpty()) return ""
        return "PAMIĘĆ UŻYTKOWNIKA (użyj, jeśli pasuje do pytania):\n" +
            top.joinToString("\n") { "- ${it.title}: ${it.content.take(300)}" }
    }

    private fun parsePlan(content: String): List<TaskPlanStep> {
        return try {
            val start = content.indexOf('{')
            val end = content.lastIndexOf('}')
            if (start < 0 || end <= start) return emptyList()
            val obj = JsonParser.parseString(content.substring(start, end + 1)).asJsonObject
            val arr = when {
                obj.has("plan") -> obj.getAsJsonArray("plan")
                obj.has("steps") -> obj.getAsJsonArray("steps")
                else -> return emptyList()
            }
            arr.mapIndexedNotNull { idx, el ->
                val o = el.asJsonObject
                val agentStr = (o.get("agent")?.asString ?: o.get("role")?.asString ?: "").trim().uppercase()
                val role = try { AgentRole.valueOf(agentStr) } catch (_: Exception) { null }
                if (role == null || role == AgentRole.MASTER || role == AgentRole.AUDITOR) {
                    null
                } else {
                    TaskPlanStep(
                        id = o.get("id")?.asString ?: "s$idx",
                        order = o.get("order")?.asInt ?: (idx + 1),
                        agentRole = role,
                        description = o.get("description")?.asString ?: ""
                    )
                }
            }.sortedBy { it.order }.take(6)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private suspend fun loadAppCfg(): AppCfg = AppCfg(
        maxIterations = settingDao.get("max_iterations")?.value?.toIntOrNull() ?: 8,
        timeoutSec = settingDao.get("timeout_sec")?.value?.toIntOrNull() ?: 90
    )

    private suspend fun loadTeam(timeoutSec: Int): Team {
        val providers = providerDao.getAll().map { it.toConfig() }
        val assignments = mutableMapOf<AgentRole, String>()
        settingDao.getAll().forEach { s ->
            if (s.key.startsWith(RoleRepository.PREFIX) && s.value.isNotBlank()) {
                try {
                    assignments[AgentRole.valueOf(s.key.removePrefix(RoleRepository.PREFIX))] = s.value
                } catch (_: Exception) {
                }
            }
        }
        return Team(providers, assignments, timeoutSec) { cfg, newModel ->
            // zapamiętaj poprawną nazwę modelu, żeby kolejne wiadomości nie powtarzały błędu
            scope.launch {
                try {
                    val e = providerDao.getById(cfg.id)
                    if (e != null) providerDao.upsert(e.copy(modelName = newModel))
                    log("Naprawiono nazwę modelu ${cfg.name}: ${cfg.modelName} → $newModel")
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun AiProviderEntity.toConfig() = AiProviderConfig(
        id = id,
        name = name,
        type = try { ProviderType.valueOf(type) } catch (_: Exception) { ProviderType.OPENAI_COMPATIBLE },
        baseUrl = baseUrl,
        apiKey = apiKeyEncrypted,
        modelName = modelName,
        isEnabled = isEnabled,
        isDefault = isDefault,
        maxTokens = maxTokens,
        temperature = temperature
    )

    private suspend fun ensureConversation(cid: String, userText: String) {
        val now = System.currentTimeMillis()
        if (conversationDao.getById(cid) == null) {
            val title = userText.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(40) ?: "Nowy czat"
            conversationDao.upsert(ConversationEntity(id = cid, title = title, createdAt = now, updatedAt = now))
        } else {
            conversationDao.touch(cid, now)
        }
    }

    private suspend fun handleCancelled(cid: String) {
        val partial = _streamingText.value
        if (partial.isNotBlank()) {
            addChat(MessageRole.ASSISTANT, partial.trim() + "\n\n*(odpowiedź przerwana)*", cid, AgentRole.MASTER, currentTaskId)
        }
        currentTaskId?.let { updateTaskStatus(it, TaskStatus.CANCELLED) }
        log("Zadanie anulowane.")
    }

    private suspend fun postAgentMessage(taskId: String, from: String, to: String, content: String, modelLabel: String) {
        agentMessageDao.insert(
            AgentMessageEntity(
                id = UUID.randomUUID().toString(),
                taskId = taskId,
                fromRole = from,
                toRole = to,
                content = content,
                modelLabel = modelLabel
            )
        )
    }

    private suspend fun updateTaskStatus(
        taskId: String,
        status: TaskStatus,
        result: String? = null,
        error: String? = null,
        currentStep: Int? = null
    ) {
        val t = taskDao.getById(taskId) ?: return
        val finished = status == TaskStatus.COMPLETED || status == TaskStatus.FAILED || status == TaskStatus.CANCELLED
        taskDao.upsert(
            t.copy(
                status = status.name,
                result = result ?: t.result,
                errorLog = if (error != null) t.errorLog + "\n$error" else t.errorLog,
                currentStep = currentStep ?: t.currentStep,
                updatedAt = System.currentTimeMillis(),
                completedAt = if (finished) System.currentTimeMillis() else t.completedAt
            )
        )
    }

    private suspend fun addChat(
        role: MessageRole,
        content: String,
        cid: String,
        agentRole: AgentRole? = null,
        taskId: String? = null
    ) {
        chatDao.insert(
            ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                taskId = taskId,
                role = role.name,
                content = content,
                agentRole = agentRole?.name,
                conversationId = cid
            )
        )
    }
}
