package com.aimasterpro.domain.agent

import com.aimasterpro.data.model.AgentRole
import com.aimasterpro.data.model.AiProviderConfig
import com.aimasterpro.data.model.ProviderType
import com.aimasterpro.data.model.isUsable
import com.aimasterpro.domain.provider.ProviderFactory

/**
 * Wybór modelu dla roli.
 * MASTER = model oznaczony jako domyślny (gwiazdka) — dokładnie to, co użytkownik miał ustawione dotąd.
 * Pozostałe role = model przypisany w zakładce Agenci/Modele; bez przypisania pracuje MASTER.
 */
object TeamResolver {

    fun realModels(providers: List<AiProviderConfig>): List<AiProviderConfig> =
        providers.filter { it.isUsable && it.type != ProviderType.LOCAL_STUB }

    fun hasRealModel(providers: List<AiProviderConfig>): Boolean = realModels(providers).isNotEmpty()

    fun master(providers: List<AiProviderConfig>): AiProviderConfig {
        val real = realModels(providers)
        return real.firstOrNull { it.isDefault }
            ?: real.firstOrNull()
            ?: providers.firstOrNull { it.type == ProviderType.LOCAL_STUB }
            ?: ProviderFactory.stubConfig()
    }

    fun forRole(
        role: AgentRole,
        providers: List<AiProviderConfig>,
        assignments: Map<AgentRole, String>
    ): AiProviderConfig {
        if (role == AgentRole.MASTER) return master(providers)
        val assigned = assignments[role]?.let { id ->
            realModels(providers).firstOrNull { it.id == id }
        }
        return assigned ?: master(providers)
    }
}

/**
 * Podpowiada, który model najlepiej sprawdzi się w jakiej roli — na podstawie nazwy modelu.
 * To heurystyka (nie znamy realnych benchmarków), więc wynik zawsze można zmienić ręcznie.
 */
object RoleAdvisor {

    private fun text(p: AiProviderConfig) = "${p.name} ${p.modelName} ${p.baseUrl}".lowercase()
    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }
    private fun tokens(t: String) = t.split(Regex("[^a-z0-9.]+")).toSet()

    fun score(p: AiProviderConfig, role: AgentRole): Int {
        val t = text(p)
        val tok = tokens(t)
        val strong = has(t, "opus", "sonnet", "fable", "mythos", "gpt-5", "gpt-4.1", "gpt-4o", "gemini",
            "-pro", "70b", "405b", "large", "reasoner", "r1", "grok", "235b") ||
            tok.any { it == "o1" || it == "o3" || it == "o4" }
        val coder = has(t, "coder", "code", "codestral", "devstral", "deepseek", "qwen", "sonnet", "opus",
            "gpt-4.1", "gpt-5", "fable", "mythos")
        val search = has(t, "perplexity", "sonar", "online", "search")
        val fast = has(t, "mini", "flash", "haiku", "small", "8b", "instant", "lite", "nano", "scout")

        return when (role) {
            AgentRole.MASTER -> (if (strong) 4 else 1) - (if (fast) 1 else 0) + (if (has(t, "claude", "gpt")) 1 else 0)
            AgentRole.PLANNER -> if (strong) 3 else 1
            AgentRole.AUDITOR -> if (strong) 4 else 1
            AgentRole.PROGRAMMER -> if (coder) 4 else if (strong) 2 else 1
            AgentRole.TESTER -> if (coder) 3 else if (fast) 2 else 1
            AgentRole.RESEARCHER -> if (search) 6 else if (has(t, "gemini")) 3 else if (strong) 2 else 1
            AgentRole.FILE_SPECIALIST -> (if (fast) 3 else 2) + (if (has(t, "gemini")) 1 else 0)
            AgentRole.SUMMARIZER -> if (fast) 3 else 2
        }
    }

    /** Zwraca przypisanie dla ról innych niż MASTER (rozkłada obciążenie między modele). */
    fun autoAssign(providers: List<AiProviderConfig>): Map<AgentRole, String> {
        val candidates = TeamResolver.realModels(providers)
        if (candidates.size < 2) return emptyMap()

        val load = candidates.associate { it.id to 0 }.toMutableMap()
        val result = mutableMapOf<AgentRole, String>()
        val order = listOf(
            AgentRole.PROGRAMMER, AgentRole.RESEARCHER, AgentRole.AUDITOR, AgentRole.PLANNER,
            AgentRole.TESTER, AgentRole.FILE_SPECIALIST, AgentRole.SUMMARIZER
        )
        for (role in order) {
            val best = candidates.maxByOrNull { p ->
                var s = score(p, role) * 10 - (load[p.id] ?: 0) * 4
                // audytor ma być niezależny od autora kodu
                if (role == AgentRole.AUDITOR && result[AgentRole.PROGRAMMER] == p.id) s -= 15
                s
            } ?: continue
            result[role] = best.id
            load[best.id] = (load[best.id] ?: 0) + 1
        }
        return result
    }
}
