package com.aimasterpro.domain.provider

import com.aimasterpro.data.model.AiProviderConfig
import com.aimasterpro.data.model.LlmMessage
import com.aimasterpro.data.model.LlmRequest
import com.aimasterpro.data.model.LlmResponse
import com.aimasterpro.data.model.ProviderType
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Wspólny interfejs dostawcy modeli AI.
 * - OpenAiCompatibleProvider: OpenAI, Groq, OpenRouter, Gemini, Mistral, DeepSeek, Perplexity, Ollama...
 * - AnthropicProvider: natywne API Claude (Messages API)
 */
interface LlmProvider {
    val config: AiProviderConfig

    /** Zwykłe (jednorazowe) wywołanie modelu. */
    suspend fun chat(request: LlmRequest): LlmResponse

    /** Wywołanie ze strumieniem — onDelta dostaje kolejne fragmenty tekstu. */
    suspend fun chatStream(request: LlmRequest, onDelta: (String) -> Unit): LlmResponse

    /** Lista modeli dostępnych dla danego klucza (do wyboru w formularzu). */
    suspend fun listModels(): Result<List<String>>

    /** Krótki test połączenia. Zwraca null gdy wszystko działa, w przeciwnym razie opis błędu. */
    suspend fun testConnection(): String? {
        val r = chat(
            LlmRequest(
                messages = listOf(LlmMessage("user", "Odpowiedz jednym słowem: ok")),
                model = config.modelName,
                maxTokens = 16,
                temperature = 0f
            )
        )
        return r.error
    }
}

abstract class HttpProvider(
    final override val config: AiProviderConfig,
    timeoutSec: Long
) : LlmProvider {

    protected val gson = Gson()
    protected val jsonMedia = "application/json; charset=utf-8".toMediaType()
    protected val client: OkHttpClient = BASE_CLIENT.newBuilder()
        .readTimeout(timeoutSec.coerceAtLeast(10), TimeUnit.SECONDS)
        .build()

    protected fun missingKeyError(): LlmResponse? =
        if (config.apiKey.isBlank() && config.type != ProviderType.CUSTOM) {
            LlmResponse(
                content = "",
                error = "Brak klucza API dla dostawcy: ${config.name}. Skonfiguruj klucz w zakładce Modele AI."
            )
        } else null

    protected suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { try { cancel() } catch (_: Exception) {} }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (cont.isCancelled) response.close() else cont.resume(response)
            }
        })
    }

    /** Pozwala natychmiast przerwać blokujące czytanie strumienia, gdy użytkownik kliknie "Stop". */
    protected suspend fun withCallCancel(call: Call, block: suspend () -> Unit): Unit = coroutineScope {
        val watcher = launch {
            try {
                awaitCancellation()
            } finally {
                call.cancel()
            }
        }
        try {
            block()
        } finally {
            watcher.cancel()
        }
    }

    protected fun parseError(code: Int, body: String): String {
        return try {
            val root = JsonParser.parseString(body)
            val obj = if (root.isJsonObject) root.asJsonObject else null
            val err = obj?.get("error")
            val msg = when {
                err == null || err.isJsonNull -> obj?.str("message")
                err.isJsonObject -> err.asJsonObject.str("message")
                err.isJsonPrimitive -> err.asString
                else -> null
            }
            "HTTP $code: ${msg ?: body.take(300)}"
        } catch (_: Exception) {
            "HTTP $code: ${body.take(300)}"
        }
    }

    protected class RawResult(val code: Int, val ok: Boolean, val text: String)

    /** Czyta całe ciało odpowiedzi i zawsze zamyka połączenie. */
    protected fun Response.readAll(): RawResult {
        try {
            return RawResult(code, isSuccessful, body?.string().orEmpty())
        } finally {
            close()
        }
    }

    protected fun networkError(e: Exception): LlmResponse =
        LlmResponse(content = "", error = "Błąd sieci/API: ${e.message ?: e.javaClass.simpleName}")

    protected fun retryAfterMs(resp: Response): Long {
        val sec = resp.header("retry-after")?.trim()?.toDoubleOrNull() ?: 3.0
        return (sec * 1000).toLong().coerceIn(1000L, 15000L)
    }

    companion object {
        val BASE_CLIENT: OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }
}

internal fun JsonObject.int(name: String): Int {
    val el: JsonElement = get(name) ?: return 0
    return try { if (el.isJsonNull) 0 else el.asInt } catch (_: Exception) { 0 }
}

internal fun JsonObject.str(name: String): String? {
    val el: JsonElement = get(name) ?: return null
    return if (el.isJsonNull || !el.isJsonPrimitive) null else el.asString
}

/* ===================================================================== */
/*  OpenAI-compatible                                                    */
/* ===================================================================== */

class OpenAiCompatibleProvider(
    config: AiProviderConfig,
    timeoutSec: Long = 90
) : HttpProvider(config, timeoutSec) {

    private val usesCompletionTokens = config.baseUrl.contains("api.openai.com")

    private fun buildBody(req: LlmRequest, stream: Boolean): JsonObject = JsonObject().apply {
        addProperty("model", req.model.ifBlank { config.modelName })
        add("messages", gson.toJsonTree(req.messages.map { mapOf("role" to it.role, "content" to it.content) }))
        addProperty(if (usesCompletionTokens) "max_completion_tokens" else "max_tokens", req.maxTokens)
        addProperty("temperature", req.temperature)
        if (stream) addProperty("stream", true)
    }

    private fun httpRequest(path: String, body: JsonObject?): Request {
        val b = Request.Builder().url(config.baseUrl.trimEnd('/') + path)
        if (config.apiKey.isNotBlank()) b.addHeader("Authorization", "Bearer ${config.apiKey}")
        if (config.type == ProviderType.OPENROUTER) {
            b.addHeader("HTTP-Referer", "https://aimasterpro.app")
            b.addHeader("X-Title", "AI Master Pro")
        }
        if (body != null) {
            b.addHeader("Content-Type", "application/json")
            b.post(body.toString().toRequestBody(jsonMedia))
        } else {
            b.get()
        }
        return b.build()
    }

    /**
     * POST z automatyczną adaptacją: część modeli (np. nowsze OpenAI) odrzuca "temperature" lub "max_tokens".
     * Limit zapytań (HTTP 429) ponawiamy z krótkim opóźnieniem.
     */
    private suspend fun post(body: JsonObject, stream: Boolean): Pair<Response, Call> {
        var attempt = 0
        while (true) {
            val call = client.newCall(httpRequest("/chat/completions", body))
            val resp = call.await()
            if (resp.isSuccessful || attempt >= 2) return resp to call

            if (resp.code == 429) {
                val wait = retryAfterMs(resp)
                resp.close()
                attempt++
                delay(wait)
                continue
            }
            if (resp.code == 400) {
                val peek = resp.peekBody(65536).string().lowercase()
                var changed = false
                if (body.has("temperature") && peek.contains("temperature")) {
                    body.remove("temperature"); changed = true
                }
                if (body.has("max_tokens") && peek.contains("max_completion_tokens")) {
                    val v = body.get("max_tokens"); body.remove("max_tokens")
                    body.add("max_completion_tokens", v); changed = true
                }
                if (body.has("max_completion_tokens") && peek.contains("max_tokens") && !peek.contains("max_completion_tokens")) {
                    val v = body.get("max_completion_tokens"); body.remove("max_completion_tokens")
                    body.add("max_tokens", v); changed = true
                }
                if (changed) {
                    resp.close()
                    attempt++
                    continue
                }
            }
            return resp to call
        }
    }

    override suspend fun chat(request: LlmRequest): LlmResponse = withContext(Dispatchers.IO) {
        missingKeyError()?.let { return@withContext it }
        try {
            val (resp, _) = post(buildBody(request, false), false)
            val raw = resp.readAll()
            val text = raw.text
            if (!raw.ok) return@withContext LlmResponse(content = "", error = parseError(raw.code, text))

            val json = JsonParser.parseString(text).asJsonObject
            val choices = json.getAsJsonArray("choices")
            val first = if (choices != null && choices.size() > 0) choices[0].asJsonObject else null
            val content = first?.getAsJsonObject("message")?.str("content") ?: ""
            LlmResponse(
                content = content.trim(),
                model = json.str("model") ?: request.model,
                finishReason = first?.str("finish_reason") ?: "",
                usageTokens = json.getAsJsonObject("usage")?.int("total_tokens") ?: 0
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            networkError(e)
        }
    }

    override suspend fun chatStream(request: LlmRequest, onDelta: (String) -> Unit): LlmResponse =
        withContext(Dispatchers.IO) {
            missingKeyError()?.let { return@withContext it }
            val sb = StringBuilder()
            var finish = ""
            var streamError: String? = null
            try {
                val (resp, call) = post(buildBody(request, true), true)
                try {
                    if (!resp.isSuccessful) {
                        val t = resp.body?.string().orEmpty()
                        return@withContext LlmResponse(content = "", error = parseError(resp.code, t))
                    }
                    withCallCancel(call) {
                        val source = resp.body?.source()
                        if (source != null) {
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val line = source.readUtf8Line() ?: break
                                if (!line.startsWith("data:")) continue
                                val data = line.removePrefix("data:").trim()
                                if (data.isEmpty()) continue
                                if (data == "[DONE]") break
                                try {
                                    val obj = JsonParser.parseString(data).asJsonObject
                                    obj.getAsJsonObject("error")?.let { streamError = it.str("message") ?: "Błąd strumienia" }
                                    val choices = obj.getAsJsonArray("choices")
                                    if (choices != null && choices.size() > 0) {
                                        val c0 = choices[0].asJsonObject
                                        val piece = c0.getAsJsonObject("delta")?.str("content")
                                        if (!piece.isNullOrEmpty()) {
                                            sb.append(piece)
                                            onDelta(piece)
                                        }
                                        c0.str("finish_reason")?.let { finish = it }
                                    }
                                } catch (_: Exception) {
                                    // pojedynczy uszkodzony fragment ignorujemy
                                }
                            }
                        }
                    }
                } finally {
                    resp.close()
                }
                LlmResponse(
                    content = sb.toString(),
                    model = request.model,
                    finishReason = finish,
                    error = if (sb.isEmpty()) streamError else null
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                currentCoroutineContext().ensureActive()
                if (sb.isNotEmpty()) LlmResponse(content = sb.toString(), error = null, finishReason = "interrupted")
                else networkError(e)
            }
        }

    override suspend fun listModels(): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val call = client.newCall(httpRequest("/models", null))
            val resp = call.await()
            val raw = resp.readAll()
            val text = raw.text
            if (!raw.ok) return@withContext Result.failure(Exception(parseError(raw.code, text)))
            val arr = JsonParser.parseString(text).asJsonObject.getAsJsonArray("data")
            val ids = arr?.mapNotNull { it.asJsonObject.str("id")?.removePrefix("models/") }.orEmpty()
            Result.success(ids.sorted())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/* ===================================================================== */
/*  Anthropic (Claude) — natywne Messages API                            */
/* ===================================================================== */

class AnthropicProvider(
    config: AiProviderConfig,
    timeoutSec: Long = 90
) : HttpProvider(config, timeoutSec) {

    private fun buildBody(req: LlmRequest, stream: Boolean): JsonObject {
        val system = req.messages.filter { it.role == "system" }.joinToString("\n\n") { it.content }
        // Messages API: tylko user/assistant, naprzemiennie, pierwsza wiadomość od użytkownika.
        val merged = mutableListOf<LlmMessage>()
        for (m in req.messages.filter { it.role != "system" }) {
            if (merged.isEmpty() && m.role != "user") continue
            val last = merged.lastOrNull()
            if (last != null && last.role == m.role) {
                merged[merged.size - 1] = LlmMessage(m.role, last.content + "\n\n" + m.content)
            } else {
                merged.add(LlmMessage(m.role, m.content))
            }
        }
        return JsonObject().apply {
            addProperty("model", req.model.ifBlank { config.modelName })
            addProperty("max_tokens", req.maxTokens)
            addProperty("temperature", req.temperature.coerceIn(0f, 1f))
            if (system.isNotBlank()) addProperty("system", system)
            add("messages", gson.toJsonTree(merged.map { mapOf("role" to it.role, "content" to it.content) }))
            if (stream) addProperty("stream", true)
        }
    }

    private fun httpRequest(path: String, body: JsonObject?): Request {
        val b = Request.Builder().url(config.baseUrl.trimEnd('/') + path)
            .addHeader("x-api-key", config.apiKey)
            .addHeader("anthropic-version", "2023-06-01")
        if (body != null) {
            b.addHeader("Content-Type", "application/json")
            b.post(body.toString().toRequestBody(jsonMedia))
        } else {
            b.get()
        }
        return b.build()
    }

    private suspend fun post(body: JsonObject): Pair<Response, Call> {
        var attempt = 0
        while (true) {
            val call = client.newCall(httpRequest("/messages", body))
            val resp = call.await()
            val retryable = resp.code == 429 || resp.code == 529
            if (resp.isSuccessful || !retryable || attempt >= 2) return resp to call
            val wait = retryAfterMs(resp)
            resp.close()
            attempt++
            delay(wait)
        }
    }

    override suspend fun chat(request: LlmRequest): LlmResponse = withContext(Dispatchers.IO) {
        missingKeyError()?.let { return@withContext it }
        try {
            val (resp, _) = post(buildBody(request, false))
            val raw = resp.readAll()
            val text = raw.text
            if (!raw.ok) return@withContext LlmResponse(content = "", error = parseError(raw.code, text))

            val json = JsonParser.parseString(text).asJsonObject
            val sb = StringBuilder()
            json.getAsJsonArray("content")?.forEach { el ->
                val o = el.asJsonObject
                if (o.str("type") == "text") sb.append(o.str("text").orEmpty())
            }
            val usage = json.getAsJsonObject("usage")
            val tokens = (usage?.int("input_tokens") ?: 0) + (usage?.int("output_tokens") ?: 0)
            LlmResponse(
                content = sb.toString().trim(),
                model = json.str("model") ?: request.model,
                finishReason = json.str("stop_reason") ?: "",
                usageTokens = tokens
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            networkError(e)
        }
    }

    override suspend fun chatStream(request: LlmRequest, onDelta: (String) -> Unit): LlmResponse =
        withContext(Dispatchers.IO) {
            missingKeyError()?.let { return@withContext it }
            val sb = StringBuilder()
            var finish = ""
            var streamError: String? = null
            try {
                val (resp, call) = post(buildBody(request, true))
                try {
                    if (!resp.isSuccessful) {
                        val t = resp.body?.string().orEmpty()
                        return@withContext LlmResponse(content = "", error = parseError(resp.code, t))
                    }
                    withCallCancel(call) {
                        val source = resp.body?.source()
                        if (source != null) {
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val line = source.readUtf8Line() ?: break
                                if (!line.startsWith("data:")) continue
                                val data = line.removePrefix("data:").trim()
                                if (data.isEmpty()) continue
                                try {
                                    val obj = JsonParser.parseString(data).asJsonObject
                                    when (obj.str("type")) {
                                        "content_block_delta" -> {
                                            val delta = obj.getAsJsonObject("delta")
                                            if (delta?.str("type") == "text_delta") {
                                                val piece = delta.str("text")
                                                if (!piece.isNullOrEmpty()) {
                                                    sb.append(piece)
                                                    onDelta(piece)
                                                }
                                            }
                                        }
                                        "message_delta" -> {
                                            obj.getAsJsonObject("delta")?.str("stop_reason")?.let { finish = it }
                                        }
                                        "error" -> {
                                            streamError = obj.getAsJsonObject("error")?.str("message") ?: "Błąd strumienia"
                                        }
                                        "message_stop" -> break
                                    }
                                } catch (_: Exception) {
                                    // ignorujemy pojedynczy uszkodzony fragment
                                }
                            }
                        }
                    }
                } finally {
                    resp.close()
                }
                LlmResponse(
                    content = sb.toString(),
                    model = request.model,
                    finishReason = finish,
                    error = if (sb.isEmpty()) streamError else null
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                currentCoroutineContext().ensureActive()
                if (sb.isNotEmpty()) LlmResponse(content = sb.toString(), error = null, finishReason = "interrupted")
                else networkError(e)
            }
        }

    override suspend fun listModels(): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val call = client.newCall(httpRequest("/models?limit=100", null))
            val resp = call.await()
            val raw = resp.readAll()
            val text = raw.text
            if (!raw.ok) return@withContext Result.failure(Exception(parseError(raw.code, text)))
            val arr = JsonParser.parseString(text).asJsonObject.getAsJsonArray("data")
            Result.success(arr?.mapNotNull { it.asJsonObject.str("id") }.orEmpty())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/* ===================================================================== */
/*  Tryb lokalny (bez modelu)                                            */
/* ===================================================================== */

class StubProvider(override val config: AiProviderConfig) : LlmProvider {
    private val message = "[TRYB LOKALNY] Żaden model AI nie jest jeszcze skonfigurowany. " +
        "Przejdź do zakładki Modele AI i dodaj klucz (np. Claude, OpenAI, Gemini albo darmowy Groq)."

    override suspend fun chat(request: LlmRequest) =
        LlmResponse(content = message, model = "local-stub", finishReason = "stop")

    override suspend fun chatStream(request: LlmRequest, onDelta: (String) -> Unit): LlmResponse {
        onDelta(message)
        return LlmResponse(content = message, model = "local-stub", finishReason = "stop")
    }

    override suspend fun listModels(): Result<List<String>> = Result.success(emptyList())
    override suspend fun testConnection(): String? = null
}

object ProviderFactory {
    /**
     * recover = true: gdy dostawca odpowie, że model nie istnieje, provider sam wybierze istniejący model
     * z listy dostawcy i powiadomi onModelFixed (żeby zapisać poprawną nazwę).
     */
    fun create(
        config: AiProviderConfig,
        timeoutSec: Int = 90,
        recover: Boolean = true,
        onModelFixed: ((AiProviderConfig, String) -> Unit)? = null
    ): LlmProvider {
        val inner: LlmProvider = when (config.type) {
            ProviderType.LOCAL_STUB -> StubProvider(config)
            ProviderType.ANTHROPIC -> AnthropicProvider(config, timeoutSec.toLong())
            else -> OpenAiCompatibleProvider(config, timeoutSec.toLong())
        }
        return if (recover && config.type != ProviderType.LOCAL_STUB) RecoveringProvider(inner, onModelFixed) else inner
    }

    fun stubConfig() = AiProviderConfig(
        id = "local_stub",
        name = "Tryb lokalny (bez modelu)",
        type = ProviderType.LOCAL_STUB,
        baseUrl = "",
        modelName = "stub",
        isEnabled = true,
        isDefault = true
    )

    /** Predefiniowane wpisy (dodawane tylko jeśli ich brakuje — nigdy nie nadpisują kluczy). */
    fun presets(): List<AiProviderConfig> = listOf(
        AiProviderConfig(
            id = "anthropic",
            name = "Claude (Anthropic)",
            type = ProviderType.ANTHROPIC,
            baseUrl = "https://api.anthropic.com/v1",
            modelName = "claude-sonnet-5-5",
            isEnabled = false
        ),
        AiProviderConfig(
            id = "gemini",
            name = "Google Gemini",
            type = ProviderType.GEMINI,
            baseUrl = "https://generativelanguage.googleapis.com/v1beta/openai",
            modelName = "gemini-flash-latest",
            isEnabled = false
        ),
        AiProviderConfig(
            id = "perplexity",
            name = "Perplexity (z wyszukiwaniem)",
            type = ProviderType.OPENAI_COMPATIBLE,
            baseUrl = "https://api.perplexity.ai",
            modelName = "sonar",
            isEnabled = false
        ),
        AiProviderConfig(
            id = "groq",
            name = "Groq (darmowy limit)",
            type = ProviderType.GROQ,
            baseUrl = "https://api.groq.com/openai/v1",
            modelName = "llama-3.3-70b-versatile",
            isEnabled = false
        ),
        AiProviderConfig(
            id = "openrouter",
            name = "OpenRouter",
            type = ProviderType.OPENROUTER,
            baseUrl = "https://openrouter.ai/api/v1",
            modelName = "openrouter/auto",
            isEnabled = false
        ),
        AiProviderConfig(
            id = "openai",
            name = "OpenAI",
            type = ProviderType.OPENAI_COMPATIBLE,
            baseUrl = "https://api.openai.com/v1",
            modelName = "gpt-4o-mini",
            isEnabled = false
        ),
        AiProviderConfig(
            id = "custom",
            name = "Własny endpoint (OpenAI-compatible)",
            type = ProviderType.CUSTOM,
            baseUrl = "http://localhost:11434/v1",
            modelName = "llama3",
            isEnabled = false
        ),
        stubConfig()
    )
}

/** Szablony w formularzu "Dodaj model" — wypełniają adres, typ i przykładową nazwę modelu. */
data class ProviderTemplate(
    val label: String,
    val type: ProviderType,
    val baseUrl: String,
    val model: String
)

object ProviderTemplates {
    val all = listOf(
        ProviderTemplate("Claude", ProviderType.ANTHROPIC, "https://api.anthropic.com/v1", "claude-sonnet-5-5"),
        ProviderTemplate("OpenAI", ProviderType.OPENAI_COMPATIBLE, "https://api.openai.com/v1", "gpt-4o-mini"),
        ProviderTemplate("Gemini", ProviderType.GEMINI, "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-flash-latest"),
        ProviderTemplate("Groq", ProviderType.GROQ, "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
        ProviderTemplate("OpenRouter", ProviderType.OPENROUTER, "https://openrouter.ai/api/v1", "openrouter/auto"),
        ProviderTemplate("Mistral", ProviderType.OPENAI_COMPATIBLE, "https://api.mistral.ai/v1", "mistral-large-latest"),
        ProviderTemplate("DeepSeek", ProviderType.OPENAI_COMPATIBLE, "https://api.deepseek.com/v1", "deepseek-chat"),
        ProviderTemplate("xAI Grok", ProviderType.OPENAI_COMPATIBLE, "https://api.x.ai/v1", "grok-3"),
        ProviderTemplate("Perplexity", ProviderType.OPENAI_COMPATIBLE, "https://api.perplexity.ai", "sonar"),
        ProviderTemplate("Własny", ProviderType.CUSTOM, "http://192.168.0.10:11434/v1", "llama3")
    )
}
