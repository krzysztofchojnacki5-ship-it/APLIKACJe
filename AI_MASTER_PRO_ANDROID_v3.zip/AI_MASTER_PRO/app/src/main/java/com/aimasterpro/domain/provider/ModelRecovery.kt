package com.aimasterpro.domain.provider

import com.aimasterpro.data.model.AiProviderConfig
import com.aimasterpro.data.model.LlmRequest
import com.aimasterpro.data.model.LlmResponse

/**
 * Wykrywa błąd „model nie istnieje / wycofany” i dobiera istniejący model z listy dostawcy.
 */
object ModelRecovery {

    private val modelWords = listOf(
        "not found", "not_found", "does not exist", "doesn't exist", "unknown model", "invalid model",
        "model_not_found", "decommission", "deprecated", "no longer", "not supported", "unsupported",
        "no endpoints", "is not a valid model", "model not", "no such model", "not available"
    )
    private val notModelWords = listOf("rate limit", "rate_limit", "quota", "api key", "api_key", "credit", "billing", "unauthorized", "authentication")
    private val skipFamilies = listOf(
        "embed", "whisper", "tts", "audio", "image", "moderation", "guard", "dall", "realtime",
        "transcribe", "rerank", "speech", "vision-preview"
    )

    fun looksLikeModelError(error: String?): Boolean {
        if (error == null) return false
        val e = error.lowercase()
        if (notModelWords.any { e.contains(it) }) return false
        if (!e.contains("model") && !e.contains("http 404")) return false
        return modelWords.any { e.contains(it) } || e.startsWith("http 404")
    }

    private fun tokens(name: String): List<String> =
        name.lowercase().removePrefix("models/").split(Regex("[-_:/. ]+")).filter { it.isNotEmpty() }

    fun usable(available: List<String>): List<String> =
        available.filter { m -> skipFamilies.none { m.lowercase().contains(it) } }

    /** Zwraca najbliższy istniejący model albo null. */
    fun pickReplacement(requested: String, available: List<String>): String? {
        val list = usable(available)
        if (list.isEmpty()) return null
        val req = requested.trim().lowercase().removePrefix("models/")
        list.firstOrNull { it.lowercase().removePrefix("models/") == req }?.let { return it }

        val rt = tokens(req)
        val wantsFree = req.endsWith(":free")
        var best: String? = null
        var bestScore = 0
        for (m in list) {
            val mt = tokens(m)
            var common = 0
            while (common < rt.size && common < mt.size && rt[common] == mt[common]) common++
            if (common == 0) continue
            var score = common * 10
            if (wantsFree == m.lowercase().endsWith(":free")) score += 3
            if (m.lowercase().startsWith(req) || req.startsWith(m.lowercase())) score += 5
            val better = score > bestScore || (score == bestScore && best != null && m > best!!)
            if (better) {
                best = m
                bestScore = score
            }
        }
        return best
    }
}

/**
 * Dekorator: przy błędzie „zły model” pobiera listę modeli dostawcy, wybiera istniejący, ponawia
 * zapytanie i (przez onFixed) zapamiętuje poprawną nazwę. Gdy nic nie pasuje, zwraca zrozumiały komunikat.
 */
class RecoveringProvider(
    private val inner: LlmProvider,
    private val onFixed: ((AiProviderConfig, String) -> Unit)?
) : LlmProvider {

    override val config: AiProviderConfig get() = inner.config

    @Volatile private var fixedModel: String? = null
    @Volatile private var available: List<String>? = null

    private fun effective(r: LlmRequest): LlmRequest {
        val f = fixedModel
        return if (f != null) r.copy(model = f) else r
    }

    private suspend fun alternative(current: String): String? {
        val list = available ?: (inner.listModels().getOrNull() ?: emptyList()).also { available = it }
        if (list.isEmpty()) return null
        val alt = ModelRecovery.pickReplacement(current, list)
        return if (alt != null && !alt.equals(current, ignoreCase = true)) alt else null
    }

    private fun explain(model: String, original: String?): String {
        val list = ModelRecovery.usable(available.orEmpty())
        val hint = if (list.isNotEmpty()) " Dostępne modele: ${list.take(8).joinToString(", ")}." else ""
        return "Model „$model” (${config.name}) nie istnieje lub został wycofany.$hint " +
            "Wejdź w Modele → Edytuj → Lista i wybierz poprawny model, albo użyj „Napraw nazwy modeli”. " +
            "(Szczegóły: ${original ?: "brak"})"
    }

    private fun success(alt: String) {
        fixedModel = alt
        onFixed?.invoke(config, alt)
    }

    override suspend fun chat(request: LlmRequest): LlmResponse {
        val req = effective(request)
        val r1 = inner.chat(req)
        if (!ModelRecovery.looksLikeModelError(r1.error)) return r1
        val alt = alternative(req.model) ?: return r1.copy(error = explain(req.model, r1.error))
        val r2 = inner.chat(req.copy(model = alt))
        if (r2.error == null) success(alt)
        return r2
    }

    override suspend fun chatStream(request: LlmRequest, onDelta: (String) -> Unit): LlmResponse {
        val req = effective(request)
        val r1 = inner.chatStream(req, onDelta)
        if (r1.content.isNotEmpty() || !ModelRecovery.looksLikeModelError(r1.error)) return r1
        val alt = alternative(req.model) ?: return r1.copy(error = explain(req.model, r1.error))
        val r2 = inner.chatStream(req.copy(model = alt), onDelta)
        if (r2.error == null) success(alt)
        return r2
    }

    override suspend fun listModels(): Result<List<String>> = inner.listModels()
    override suspend fun testConnection(): String? = inner.testConnection()
}
