package com.aimasterpro.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aimasterpro.AIMasterApp
import com.aimasterpro.data.model.*
import com.aimasterpro.domain.agent.AgentPrompts
import com.aimasterpro.domain.agent.RoleAdvisor
import com.aimasterpro.domain.agent.TeamResolver
import com.aimasterpro.domain.provider.ModelRecovery
import com.aimasterpro.domain.provider.ProviderFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AIMasterApp

    // ---------- Czat / rozmowy ----------

    private val _conversationId = MutableStateFlow("")
    val conversationId: StateFlow<String> = _conversationId.asStateFlow()

    val messages: StateFlow<List<ChatMessage>> = _conversationId
        .flatMapLatest { id ->
            if (id.isBlank()) flowOf(emptyList()) else app.chatRepository.observeConversation(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversations: StateFlow<List<Conversation>> = app.chatRepository.observeConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val taskIdsWithAgentChat: StateFlow<Set<String>> = app.taskRepository.observeTaskIdsWithAgentChat()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    // ---------- Pozostałe dane ----------

    val tasks: StateFlow<List<TaskEntity>> = app.taskRepository.observeTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memoryItems: StateFlow<List<MemoryItem>> = app.memoryRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val providers: StateFlow<List<AiProviderConfig>> = app.providerRepository.observeProviders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val roleAssignments: StateFlow<Map<AgentRole, String>> = app.roleRepository.observeAssignments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    /** Opis modelu MASTER do paska tytułowego czatu. */
    val masterLabel: StateFlow<String> = providers
        .map { list ->
            val m = TeamResolver.master(list)
            if (m.type == ProviderType.LOCAL_STUB) "Brak modelu — dodaj w zakładce Modele" else m.modelName
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    // ---------- Stan pracy orkiestratora ----------

    val isRunning: StateFlow<Boolean> = app.orchestrator.isRunning
    val progressLog: StateFlow<List<String>> = app.orchestrator.progressLog
    val activeTaskId: StateFlow<String?> = app.orchestrator.activeTaskId
    val runningConversationId: StateFlow<String?> = app.orchestrator.runningConversationId
    val streamingText: StateFlow<String> = app.orchestrator.streamingText
    val statusText: StateFlow<String> = app.orchestrator.statusText
    val activeRole: StateFlow<AgentRole?> = app.orchestrator.activeRole

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _backupMessage = MutableStateFlow<String?>(null)
    val backupMessage: StateFlow<String?> = _backupMessage.asStateFlow()

    val agentRoles = AgentRole.entries

    init {
        viewModelScope.launch {
            _settings.value = app.settingsRepository.getAppSettings()

            // Wróć do ostatniej rozmowy (lub najnowszej); jeśli brak — pusty nowy czat.
            val saved = app.settingsRepository.get(LAST_CONVERSATION_KEY)
            val id = when {
                saved.isNotBlank() && app.chatRepository.conversationExists(saved) -> saved
                else -> app.chatRepository.latestConversationId() ?: UUID.randomUUID().toString()
            }
            _conversationId.value = id
        }
    }

    // ---------- Czat ----------

    fun onInputChange(text: String) {
        _inputText.value = text
    }

    fun sendMessage() {
        val text = _inputText.value.trim()
        if (text.isBlank() || isRunning.value) return
        var cid = _conversationId.value
        if (cid.isBlank()) {
            cid = UUID.randomUUID().toString()
            selectConversation(cid)
        }
        _inputText.value = ""
        app.orchestrator.sendMessage(cid, text)
    }

    /** "Wygeneruj ponownie": usuwa ostatnią odpowiedź asystenta i odpowiada na ostatnie pytanie jeszcze raz. */
    fun regenerate() {
        if (isRunning.value) return
        val cid = _conversationId.value
        val list = messages.value
        val lastUserIdx = list.indexOfLast { it.role == MessageRole.USER }
        if (cid.isBlank() || lastUserIdx < 0) return
        val userText = list[lastUserIdx].content
        val toDelete = list.drop(lastUserIdx + 1).map { it.id }
        viewModelScope.launch {
            app.chatRepository.deleteMessages(toDelete)
            app.orchestrator.sendMessage(cid, userText, addUserMessage = false)
        }
    }

    fun cancelTask() {
        app.orchestrator.cancel()
    }

    fun newChat() {
        if (isRunning.value) return
        selectConversation(UUID.randomUUID().toString())
    }

    fun selectConversation(id: String) {
        _conversationId.value = id
        viewModelScope.launch { app.settingsRepository.set(LAST_CONVERSATION_KEY, id) }
    }

    fun deleteConversation(id: String) {
        if (isRunning.value && runningConversationId.value == id) return
        viewModelScope.launch {
            app.chatRepository.deleteConversation(id)
            if (_conversationId.value == id) {
                selectConversation(app.chatRepository.latestConversationId() ?: UUID.randomUUID().toString())
            }
        }
    }

    fun agentMessages(taskId: String): Flow<List<AgentMessage>> = app.taskRepository.observeAgentMessages(taskId)

    // ---------- Zadania ----------

    fun resumeTask(taskId: String) {
        if (isRunning.value) return
        viewModelScope.launch {
            val task = app.taskRepository.getTask(taskId) ?: return@launch
            val cid = UUID.randomUUID().toString()
            selectConversation(cid)
            app.orchestrator.sendMessage(cid, task.userCommand)
        }
    }

    fun deleteTask(taskId: String) {
        viewModelScope.launch { app.taskRepository.deleteTask(taskId) }
    }

    // ---------- Pamięć ----------

    fun saveMemory(title: String, content: String, tags: List<String> = emptyList()) {
        viewModelScope.launch { app.memoryRepository.save(title, content, tags) }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch { app.memoryRepository.delete(id) }
    }

    fun clearMemory() {
        viewModelScope.launch { app.memoryRepository.clearAll() }
    }

    // ---------- Modele i role ----------

    /** Zapisuje model razem z rolami, które ma pełnić (MASTER = domyślny). */
    fun saveProviderWithRoles(config: AiProviderConfig, roles: Set<AgentRole>) {
        viewModelScope.launch {
            val isMaster = AgentRole.MASTER in roles || config.isDefault
            app.providerRepository.save(config.copy(isDefault = isMaster, isEnabled = config.isEnabled))
            val current = app.roleRepository.getAssignments()
            AgentRole.entries.filter { it != AgentRole.MASTER }.forEach { role ->
                when {
                    role in roles -> app.roleRepository.assign(role, config.id)
                    current[role] == config.id -> app.roleRepository.assign(role, null)
                }
            }
        }
    }

    fun saveProvider(config: AiProviderConfig) {
        viewModelScope.launch { app.providerRepository.save(config) }
    }

    fun deleteProvider(id: String) {
        viewModelScope.launch { app.providerRepository.delete(id) }
    }

    fun setProviderEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch {
            val p = providers.value.find { it.id == id } ?: return@launch
            app.providerRepository.save(p.copy(isEnabled = enabled))
        }
    }

    fun setDefaultProvider(id: String) {
        viewModelScope.launch {
            val p = providers.value.find { it.id == id } ?: return@launch
            app.providerRepository.save(p.copy(isDefault = true, isEnabled = true))
        }
    }

    /** Przypisuje rolę do modelu. Dla MASTER ustawia model domyślny. providerId == null → rola wraca do MASTER. */
    fun assignRole(role: AgentRole, providerId: String?) {
        if (role == AgentRole.MASTER) {
            if (providerId != null) setDefaultProvider(providerId)
            return
        }
        viewModelScope.launch { app.roleRepository.assign(role, providerId) }
    }

    /** Automatycznie dobiera modele do ról na podstawie ich nazw (można później zmienić ręcznie). */
    fun autoAssignRoles() {
        viewModelScope.launch {
            val result = RoleAdvisor.autoAssign(providers.value)
            AgentRole.entries.filter { it != AgentRole.MASTER }.forEach { role ->
                app.roleRepository.assign(role, result[role])
            }
        }
    }

    suspend fun testProvider(config: AiProviderConfig): String? =
        ProviderFactory.create(config, _settings.value.requestTimeoutSec, recover = false).testConnection()

    suspend fun fetchModels(config: AiProviderConfig): Result<List<String>> =
        ProviderFactory.create(config, 30, recover = false).listModels()

    /**
     * Sprawdza każdy aktywny model: jeśli jego nazwa nie występuje na liście dostawcy,
     * podmienia ją na najbliższy istniejący model. Zwraca raport tekstowy.
     */
    suspend fun repairModels(): String {
        val targets = TeamResolver.realModels(providers.value)
        if (targets.isEmpty()) return "Brak aktywnych modeli z kluczem."
        val report = StringBuilder()
        for (p in targets) {
            val r = ProviderFactory.create(p, 30, recover = false).listModels()
            val list = r.getOrNull()
            when {
                list == null -> report.append("• ${p.name}: nie udało się pobrać listy (${r.exceptionOrNull()?.message})\n")
                list.isEmpty() -> report.append("• ${p.name}: dostawca nie zwrócił listy modeli\n")
                list.any { it.equals(p.modelName, ignoreCase = true) } -> report.append("• ${p.name}: model „${p.modelName}” jest poprawny ✓\n")
                else -> {
                    val alt = ModelRecovery.pickReplacement(p.modelName, list)
                    if (alt == null) {
                        report.append("• ${p.name}: model „${p.modelName}” nie istnieje, nic nie pasuje — wybierz ręcznie (Edytuj → Lista)\n")
                    } else {
                        app.providerRepository.save(p.copy(modelName = alt))
                        report.append("• ${p.name}: „${p.modelName}” → „$alt” (naprawiono)\n")
                    }
                }
            }
        }
        return report.toString().trim()
    }

    // ---------- Ustawienia ----------

    fun updateSettings(s: AppSettings) {
        viewModelScope.launch {
            app.settingsRepository.saveAppSettings(s)
            _settings.value = s
        }
    }

    fun clearChat() {
        val id = _conversationId.value
        if (id.isBlank() || isRunning.value) return
        deleteConversation(id)
    }

    // ---------- Kopia zapasowa ----------

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            _backupMessage.value = try {
                val json = app.backupRepository.export()
                withContext(Dispatchers.IO) {
                    app.contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("Nie można zapisać pliku.")
                }
                "Zapisano kopię zapasową (modele, klucze, role, pamięć)."
            } catch (e: Exception) {
                "Błąd zapisu kopii: ${e.message}"
            }
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch {
            _backupMessage.value = try {
                val json = withContext(Dispatchers.IO) {
                    app.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                        ?: throw IllegalStateException("Nie można odczytać pliku.")
                }
                app.backupRepository.restore(json)
            } catch (e: Exception) {
                "Błąd importu: ${e.message}"
            }
        }
    }

    fun clearBackupMessage() {
        _backupMessage.value = null
    }

    fun agentDisplayName(role: AgentRole) = AgentPrompts.roleDisplayName(role)
    fun agentDescription(role: AgentRole) = AgentPrompts.roleDescription(role)

    companion object {
        private const val LAST_CONVERSATION_KEY = "last_conversation"
    }
}
