package com.aimasterpro.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aimasterpro.data.model.AgentMessage
import com.aimasterpro.domain.agent.AgentPrompts
import com.aimasterpro.ui.MainViewModel
import com.aimasterpro.ui.theme.Accent
import com.aimasterpro.ui.theme.SurfaceVariant
import com.aimasterpro.ui.theme.TextSecondary

/**
 * Prywatna rozmowa agentów (MASTER <-> specjaliści). Użytkownik widzi ją tylko po kliknięciu.
 * Odświeża się na żywo, gdy zespół jeszcze pracuje.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentTranscriptSheet(taskId: String, viewModel: MainViewModel, onDismiss: () -> Unit) {
    val flow = remember(taskId) { viewModel.agentMessages(taskId) }
    val list by flow.collectAsState(initial = emptyList())
    val isRunning by viewModel.isRunning.collectAsState()
    val activeTaskId by viewModel.activeTaskId.collectAsState()
    val live = isRunning && activeTaskId == taskId
    val listState = rememberLazyListState()

    LaunchedEffect(list.size) {
        if (list.isNotEmpty()) listState.animateScrollToItem(list.size - 1)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(Modifier.fillMaxHeight(0.92f)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Rozmowa agentów", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (live) "Zespół pracuje teraz — odświeżane na żywo" else "Tak MASTER i specjaliści ustalali odpowiedź",
                        color = if (live) Accent else TextSecondary,
                        fontSize = 12.sp
                    )
                }
                if (live) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Accent)
            }
            HorizontalDivider(Modifier.padding(top = 8.dp))

            if (list.isEmpty()) {
                Text(
                    "Brak wiadomości.",
                    color = TextSecondary,
                    modifier = Modifier.padding(16.dp)
                )
            }
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list, key = { it.id }) { AgentMessageCard(it) }
            }
        }
    }
}

@Composable
private fun AgentMessageCard(m: AgentMessage) {
    val fromMaster = m.from == "MASTER"
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (fromMaster) Accent.copy(alpha = 0.12f) else SurfaceVariant
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                "${AgentPrompts.displayForKey(m.from)}  →  ${AgentPrompts.displayForKey(m.to)}",
                fontWeight = FontWeight.SemiBold,
                color = if (fromMaster) Accent else MaterialTheme.colorScheme.onSurface,
                fontSize = 13.sp
            )
            if (m.modelLabel.isNotBlank()) {
                Text(m.modelLabel, color = TextSecondary, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            MarkdownText(m.content, fontSize = 14.sp)
        }
    }
}
