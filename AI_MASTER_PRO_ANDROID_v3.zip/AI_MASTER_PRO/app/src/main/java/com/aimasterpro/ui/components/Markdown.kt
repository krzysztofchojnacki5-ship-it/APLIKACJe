package com.aimasterpro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aimasterpro.ui.theme.Accent
import com.aimasterpro.ui.theme.TextSecondary

/* ------------------------------------------------------------------ */
/*  Parser Markdown (lekki, bez zewnętrznych bibliotek)               */
/* ------------------------------------------------------------------ */

sealed interface MdBlock {
    data class Paragraph(val text: String) : MdBlock
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Bullet(val marker: String, val text: String, val indent: Int) : MdBlock
    data class Code(val lang: String, val code: String) : MdBlock
    data class Quote(val text: String) : MdBlock
    data class Table(val rows: List<List<String>>) : MdBlock
    data object Rule : MdBlock
}

private val headingRegex = Regex("^(#{1,6})\\s+(.*)$")
private val bulletRegex = Regex("^(\\s*)([-*+•])\\s+(.*)$")
private val numberedRegex = Regex("^(\\s*)(\\d+)[.)]\\s+(.*)$")
private val ruleRegex = Regex("^\\s*([-*_])(\\s*\\1){2,}\\s*$")
private val tableSepRegex = Regex("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?\\s*$")

fun parseMarkdown(src: String): List<MdBlock> {
    val lines = src.replace("\r\n", "\n").split("\n")
    val out = mutableListOf<MdBlock>()
    val para = StringBuilder()

    fun flushParagraph() {
        if (para.isNotEmpty()) {
            out.add(MdBlock.Paragraph(para.toString().trimEnd()))
            para.clear()
        }
    }

    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()

        // blok kodu
        if (trimmed.startsWith("```")) {
            flushParagraph()
            val lang = trimmed.removePrefix("```").trim()
            val code = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trim().startsWith("```")) {
                if (code.isNotEmpty()) code.append('\n')
                code.append(lines[i])
                i++
            }
            out.add(MdBlock.Code(lang, code.toString()))
            i++ // zamykający ```
            continue
        }

        if (trimmed.isEmpty()) {
            flushParagraph()
            i++
            continue
        }

        val h = headingRegex.matchEntire(trimmed)
        if (h != null) {
            flushParagraph()
            out.add(MdBlock.Heading(h.groupValues[1].length, h.groupValues[2].trim()))
            i++
            continue
        }

        if (ruleRegex.matches(trimmed)) {
            flushParagraph()
            out.add(MdBlock.Rule)
            i++
            continue
        }

        // tabela: linia z '|' i linia separatora pod spodem
        if (trimmed.contains('|') && i + 1 < lines.size && tableSepRegex.matches(lines[i + 1]) && lines[i + 1].contains('-')) {
            flushParagraph()
            val rows = mutableListOf<List<String>>()
            rows.add(splitRow(trimmed))
            i += 2
            while (i < lines.size && lines[i].contains('|') && lines[i].isNotBlank()) {
                rows.add(splitRow(lines[i].trim()))
                i++
            }
            out.add(MdBlock.Table(rows))
            continue
        }

        if (trimmed.startsWith(">")) {
            flushParagraph()
            val q = StringBuilder()
            while (i < lines.size && lines[i].trim().startsWith(">")) {
                if (q.isNotEmpty()) q.append('\n')
                q.append(lines[i].trim().removePrefix(">").trimStart())
                i++
            }
            out.add(MdBlock.Quote(q.toString()))
            continue
        }

        val b = bulletRegex.matchEntire(line)
        if (b != null) {
            flushParagraph()
            out.add(MdBlock.Bullet("•", b.groupValues[3], b.groupValues[1].length / 2))
            i++
            continue
        }
        val n = numberedRegex.matchEntire(line)
        if (n != null) {
            flushParagraph()
            out.add(MdBlock.Bullet(n.groupValues[2] + ".", n.groupValues[3], n.groupValues[1].length / 2))
            i++
            continue
        }

        if (para.isNotEmpty()) para.append('\n')
        para.append(trimmed)
        i++
    }
    flushParagraph()
    return out
}

private fun splitRow(line: String): List<String> =
    line.trim().removePrefix("|").removeSuffix("|").split("|").map { it.trim() }

/* ------------------------------------------------------------------ */
/*  Formatowanie w linii: **pogrubienie**, *kursywa*, `kod`, [link](url) */
/* ------------------------------------------------------------------ */

fun inlineMarkdown(text: String, codeBg: Color, linkColor: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        val c = text[i]
        when {
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end > i + 2) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(inlineMarkdown(text.substring(i + 2, end), codeBg, linkColor))
                    }
                    i = end + 2
                } else {
                    append("**")
                    i += 2
                }
            }
            c == '`' -> {
                val end = text.indexOf('`', i + 1)
                if (end > i) {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg, fontSize = 14.sp)) {
                        append(text.substring(i + 1, end))
                    }
                    i = end + 1
                } else {
                    append(c)
                    i++
                }
            }
            c == '*' && i + 1 < text.length && text[i + 1] != ' ' -> {
                val end = text.indexOf('*', i + 1)
                if (end > i + 1) {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(text.substring(i + 1, end))
                    }
                    i = end + 1
                } else {
                    append(c)
                    i++
                }
            }
            c == '[' -> {
                val close = text.indexOf(']', i + 1)
                val urlEnd = if (close > i && text.startsWith("](", close)) text.indexOf(')', close + 2) else -1
                if (urlEnd > close) {
                    val label = text.substring(i + 1, close)
                    val url = text.substring(close + 2, urlEnd).trim()
                    val mark = pushStringAnnotation("URL", url)
                    withStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)) {
                        append(label)
                    }
                    pop(mark)
                    i = urlEnd + 1
                } else {
                    append(c)
                    i++
                }
            }
            else -> {
                append(c)
                i++
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Composable                                                         */
/* ------------------------------------------------------------------ */

@Composable
fun MarkdownText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.onSurface,
    fontSize: TextUnit = 16.sp
) {
    val blocks = remember(text) { parseMarkdown(text) }
    val codeBg = Color(0xFF2E2E2E)
    val lineHeight = fontSize * 1.5f

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        blocks.forEach { block ->
            when (block) {
                is MdBlock.Paragraph -> InlineText(block.text, color, fontSize, lineHeight, codeBg)

                is MdBlock.Heading -> {
                    val size = when (block.level) {
                        1 -> fontSize * 1.45f
                        2 -> fontSize * 1.3f
                        3 -> fontSize * 1.15f
                        else -> fontSize
                    }
                    InlineText(block.text, color, size, size * 1.35f, codeBg, FontWeight.Bold)
                }

                is MdBlock.Bullet -> Row(Modifier.padding(start = (block.indent * 16).dp)) {
                    Text(
                        block.marker,
                        color = TextSecondary,
                        fontSize = fontSize,
                        modifier = Modifier.width(if (block.marker == "•") 18.dp else 26.dp)
                    )
                    InlineText(block.text, color, fontSize, lineHeight, codeBg)
                }

                is MdBlock.Code -> CodeBlock(block.lang, block.code)

                is MdBlock.Quote -> Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(
                        Modifier
                            .width(3.dp)
                            .fillMaxHeight()
                            .background(Accent.copy(alpha = 0.7f))
                    )
                    Spacer(Modifier.width(10.dp))
                    InlineText(block.text, TextSecondary, fontSize, lineHeight, codeBg)
                }

                is MdBlock.Table -> TableBlock(block.rows, color, fontSize, codeBg)

                MdBlock.Rule -> HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            }
        }
    }
}

@Composable
private fun InlineText(
    text: String,
    color: Color,
    size: TextUnit,
    lineHeight: TextUnit,
    codeBg: Color,
    weight: FontWeight? = null
) {
    val annotated = remember(text) { inlineMarkdown(text, codeBg, Accent) }
    val style = TextStyle(color = color, fontSize = size, lineHeight = lineHeight, fontWeight = weight)
    val hasLinks = annotated.getStringAnnotations("URL", 0, annotated.length).isNotEmpty()
    if (hasLinks) {
        val uriHandler = LocalUriHandler.current
        ClickableText(
            text = annotated,
            style = style,
            onClick = { offset ->
                annotated.getStringAnnotations("URL", offset, offset).firstOrNull()?.let {
                    try { uriHandler.openUri(it.item) } catch (_: Exception) {}
                }
            }
        )
    } else {
        Text(annotated, style = style)
    }
}

@Composable
fun CodeBlock(lang: String, code: String) {
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF161616))
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xFF2A2A2A))
                .padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                lang.ifBlank { "kod" },
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { clipboard.setText(AnnotatedString(code)) }) {
                Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp), tint = TextSecondary)
                Spacer(Modifier.width(4.dp))
                Text("Kopiuj", color = TextSecondary, fontSize = 12.sp)
            }
        }
        Box(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
            Text(
                code,
                color = Color(0xFFE6E6E6),
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 19.sp,
                softWrap = false
            )
        }
    }
}

@Composable
private fun TableBlock(rows: List<List<String>>, color: Color, size: TextUnit, codeBg: Color) {
    if (rows.isEmpty()) return
    val cols = rows.maxOf { it.size }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1E1E1E))
    ) {
        rows.forEachIndexed { r, row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .then(if (r == 0) Modifier.background(Color(0xFF2A2A2A)) else Modifier)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                for (c in 0 until cols) {
                    Box(Modifier.weight(1f).padding(end = 6.dp)) {
                        InlineText(
                            row.getOrElse(c) { "" }, color, size * 0.9f, size * 1.25f, codeBg,
                            if (r == 0) FontWeight.Bold else null
                        )
                    }
                }
            }
            if (r < rows.size - 1) HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        }
    }
}
