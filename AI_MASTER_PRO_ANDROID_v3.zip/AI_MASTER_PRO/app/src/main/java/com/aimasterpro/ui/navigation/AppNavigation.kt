package com.aimasterpro.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aimasterpro.ui.MainViewModel
import com.aimasterpro.ui.screens.agents.AgentsScreen
import com.aimasterpro.ui.screens.chat.ChatScreen
import com.aimasterpro.ui.screens.memory.MemoryScreen
import com.aimasterpro.ui.screens.models.ModelsScreen
import com.aimasterpro.ui.screens.settings.SettingsScreen
import com.aimasterpro.ui.screens.tasks.TasksScreen
import com.aimasterpro.ui.theme.SidebarDark
import com.aimasterpro.ui.theme.SurfaceVariant
import com.aimasterpro.ui.theme.TextSecondary
import kotlinx.coroutines.launch

object Routes {
    const val CHAT = "chat"
    const val AGENTS = "agents"
    const val TASKS = "tasks"
    const val MEMORY = "memory"
    const val MODELS = "models"
    const val SETTINGS = "settings"
}

private data class NavItem(val route: String, val label: String, val icon: ImageVector)

private val navItems = listOf(
    NavItem(Routes.MODELS, "Modele AI", Icons.Filled.SmartToy),
    NavItem(Routes.AGENTS, "Agenci", Icons.Filled.Groups),
    NavItem(Routes.TASKS, "Zadania", Icons.Outlined.Assignment),
    NavItem(Routes.MEMORY, "Pamięć", Icons.Outlined.Memory),
    NavItem(Routes.SETTINGS, "Ustawienia", Icons.Filled.Settings)
)

@Composable
fun AppNavigation(viewModel: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: Routes.CHAT
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val conversations by viewModel.conversations.collectAsState()
    val currentId by viewModel.conversationId.collectAsState()
    val isRunning by viewModel.isRunning.collectAsState()
    var query by remember { mutableStateOf("") }

    fun closeDrawer() { scope.launch { drawerState.close() } }
    fun goTo(r: String) {
        navController.navigate(r) { launchSingleTop = true }
        closeDrawer()
    }
    fun goChat() {
        if (route != Routes.CHAT) navController.popBackStack(Routes.CHAT, inclusive = false)
        closeDrawer()
    }

    BackHandler(enabled = drawerState.isOpen) { closeDrawer() }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = route == Routes.CHAT || drawerState.isOpen,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = SidebarDark, modifier = Modifier.widthIn(max = 320.dp)) {
                Column(
                    Modifier
                        .fillMaxHeight()
                        .padding(horizontal = 10.dp)
                ) {
                    // wyszukiwarka czatów
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp, bottom = 8.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceVariant)
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.onSurface),
                            modifier = Modifier.weight(1f),
                            decorationBox = { inner ->
                                Box {
                                    if (query.isEmpty()) Text("Szukaj", color = TextSecondary, fontSize = 15.sp)
                                    inner()
                                }
                            }
                        )
                    }

                    DrawerRow(Icons.Outlined.Edit, "Nowy czat", false, enabled = !isRunning, onClick = {
                        viewModel.newChat()
                        goChat()
                    })
                    navItems.forEach { item ->
                        DrawerRow(item.icon, item.label, route == item.route, onClick = { goTo(item.route) })
                    }

                    Text(
                        "Czaty",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(start = 12.dp, top = 18.dp, bottom = 6.dp)
                    )
                    val filtered = remember(conversations, query) {
                        if (query.isBlank()) conversations else conversations.filter { it.title.contains(query, ignoreCase = true) }
                    }
                    LazyColumn(Modifier.weight(1f)) {
                        items(filtered, key = { it.id }) { c ->
                            var menu by remember { mutableStateOf(false) }
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (c.id == currentId && route == Routes.CHAT) SurfaceVariant else androidx.compose.ui.graphics.Color.Transparent)
                                    .clickable {
                                        viewModel.selectConversation(c.id)
                                        goChat()
                                    }
                                    .padding(start = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    c.title,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(vertical = 12.dp)
                                )
                                Box {
                                    IconButton(onClick = { menu = true }) {
                                        Icon(Icons.Filled.MoreHoriz, contentDescription = "Opcje czatu", tint = TextSecondary)
                                    }
                                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                        DropdownMenuItem(
                                            text = { Text("Usuń czat", color = MaterialTheme.colorScheme.error) },
                                            leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                            onClick = {
                                                menu = false
                                                viewModel.deleteConversation(c.id)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    ) {
        NavHost(
            navController = navController,
            startDestination = Routes.CHAT,
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .navigationBarsPadding()
                .imePadding()
        ) {
            composable(Routes.CHAT) {
                ChatScreen(viewModel, onOpenDrawer = { scope.launch { drawerState.open() } })
            }
            val back: () -> Unit = { navController.popBackStack() }
            composable(Routes.AGENTS) { AgentsScreen(viewModel, onBack = back) }
            composable(Routes.TASKS) { TasksScreen(viewModel, onBack = back) }
            composable(Routes.MEMORY) { MemoryScreen(viewModel, onBack = back) }
            composable(Routes.MODELS) { ModelsScreen(viewModel, onBack = back) }
            composable(Routes.SETTINGS) { SettingsScreen(viewModel, onBack = back) }
        }
    }
}

@Composable
private fun DrawerRow(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) SurfaceVariant else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp), tint = if (enabled) MaterialTheme.colorScheme.onSurface else TextSecondary)
        Spacer(Modifier.width(14.dp))
        Text(label, fontSize = 16.sp, color = if (enabled) MaterialTheme.colorScheme.onSurface else TextSecondary)
    }
}
