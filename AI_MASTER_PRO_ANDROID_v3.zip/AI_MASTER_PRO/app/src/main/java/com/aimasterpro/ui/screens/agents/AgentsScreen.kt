package com.aimasterpro.ui.screens.agents

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aimasterpro.data.model.AgentRole
import com.aimasterpro.data.model.AiProviderConfig
import com.aimasterpro.domain.agent.TeamResolver
import com.aimasterpro.ui.MainViewModel
import com.aimasterpro.ui.components.BackButton
import com.aimasterpro.ui.theme.Accent
import com.aimasterpro.ui.theme.SuccessGreen
import com.aimasterpro.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val isRunning by viewModel.isRunning.collectAsState()
    val progressLog by viewModel.progressLog.collectAsState()
    val activeRole by viewModel.activeRole.collectAsState()
    val providers by viewModel.providers.collectAsState()
    val assignments by viewModel.roleAssignments.collectAsState()
    val realModels = remember(providers) { TeamResolver.realModels(providers) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            navigationIcon = { BackButton(onBack) },
            title = { Text("Agenci", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Zespół", fontWeight = FontWeight.SemiBold, color = Accent)
                        Text(
                            "Wybierz, który model pełni jaką rolę. MASTER rozmawia z Tobą, reszta pracuje w tle " +
                                "i raportuje do MASTER. Rozmowy agentów otworzysz pod odpowiedzią w czacie.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { viewModel.autoAssignRoles() },
                            enabled = realModels.size >= 2 && !isRunning,
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = androidx.compose.ui.graphics.Color.Black)
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Auto-przydziel role")
                        }
                        if (realModels.size < 2) {
                            Text(
                                "Dodaj co najmniej 2 aktywne modele w zakładce Modele, aby rozdzielić role.",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }

            if (isRunning && progressLog.isNotEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Aktywna praca zespołu", color = Accent, fontWeight = FontWeight.SemiBold)
                            progressLog.takeLast(4).forEach {
                                Text("• $it", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }

            items(viewModel.agentRoles) { role ->
                val assigned: AiProviderConfig? = if (role == AgentRole.MASTER) {
                    TeamResolver.master(providers)
                } else {
                    assignments[role]?.let { id -> realModels.firstOrNull { it.id == id } }
                }
                AgentCard(
                    role = role,
                    name = viewModel.agentDisplayName(role),
                    description = viewModel.agentDescription(role),
                    working = isRunning && activeRole == role,
                    current = assigned,
                    models = realModels,
                    onPick = { viewModel.assignRole(role, it) }
                )
            }
        }
    }
}

@Composable
private fun AgentCard(
    role: AgentRole,
    name: String,
    description: String,
    working: Boolean,
    current: AiProviderConfig?,
    models: List<AiProviderConfig>,
    onPick: (String?) -> Unit
) {
    val isMaster = role == AgentRole.MASTER
    var open by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isMaster)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            else
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.Circle,
                    contentDescription = null,
                    tint = if (working) SuccessGreen else TextSecondary,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                    Text(description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
            Spacer(Modifier.height(8.dp))
            Box {
                OutlinedButton(onClick = { open = true }, enabled = models.isNotEmpty()) {
                    Text(
                        current?.let { "${it.name} · ${it.modelName}" } ?: "Domyślny (model MASTER)",
                        maxLines = 1
                    )
                    Icon(Icons.Filled.ExpandMore, contentDescription = null)
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    if (!isMaster) {
                        DropdownMenuItem(text = { Text("Domyślny (model MASTER)") }, onClick = {
                            onPick(null)
                            open = false
                        })
                    }
                    models.forEach { m ->
                        DropdownMenuItem(text = { Text("${m.name} · ${m.modelName}") }, onClick = {
                            onPick(m.id)
                            open = false
                        })
                    }
                }
            }
        }
    }
}
