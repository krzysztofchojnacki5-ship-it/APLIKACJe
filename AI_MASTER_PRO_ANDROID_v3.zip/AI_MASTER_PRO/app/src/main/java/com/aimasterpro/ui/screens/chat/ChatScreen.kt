package com.aimasterpro.ui.screens.chat

import android.content.Intent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aimasterpro.data.model.ChatMessage
import com.aimasterpro.data.model.MessageRole
import com.aimasterpro.domain.agent.TeamResolver
import com.aimasterpro.ui.MainViewModel
import com.aimasterpro.ui.components.AgentTranscriptSheet
import com.aimasterpro.ui.components.MarkdownText
import com.aimasterpro.ui.theme.SurfaceVariant
import com.aimasterpro.ui.theme.TextSecondary

private val UserBubble = Color(0xFF2F2F2F)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: MainViewModel, onOpenDrawer: () -> Unit) {
    val messages by viewModel.messages.collectAsState()
    val currentId by viewModel.conversationId.collectAsState()
    val input by viewModel.inputText.collectAsState()
    val isRunning by viewModel.isRunning.collectAsState()
    val runningConv by viewModel.runningConversationId.collectAsState()
    val streaming by viewModel.streamingText.collectAsState()
    val status by viewModel.statusText.collectAsState()
    val activeTaskId by viewModel.activeTaskId.collectAsState()
    val agentTaskIds by viewModel.taskIdsWithAgentChat.collectAsState()
    val masterLabel by viewModel.masterLabel.collectAsState()
    val providers by viewModel.providers.collectAsState()

    val listState = rememberLazyListState()
    var sheetTaskId by remember { mutableStateOf<String?>(null) }

    val showRunning = isRunning && runningConv == currentId
    val hasModel = TeamResolver.hasRealModel(providers)

    // Lista jest odwrócona (reverseLayout): indeks 0 = dół, przy polu wpisywania.
    LaunchedEffect(messages.size, showRunning, currentId) {
        listState.scrollToItem(0)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text("AI Master Pro", fontWeight = FontWeight.Medium, fontSize = 18.sp)
                    if (masterLabel.isNotBlank()) {
                        Text(
                            masterLabel,
                            fontSize = 12.sp,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            },
            navigationIcon = {
                IconButton(onClick = onOpenDrawer) {
                    Icon(Icons.Filled.Menu, contentDescription = "Menu")
                }
            },
            actions = {
                IconButton(onClick = { viewModel.newChat() }, enabled = !isRunning) {
                    Icon(Icons.Outlined.Edit, contentDescription = "Nowy czat")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )

        if (!hasModel) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Text(
                    "Brak aktywnego modelu AI z kluczem. Otwórz menu → Modele AI i dodaj klucz (np. Claude, OpenAI, Gemini, Groq).",
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty() && !showRunning) {
                EmptyState(onPick = { viewModel.onInputChange(it) })
            } else {
                val reversed = remember(messages) { messages.asReversed() }
                LazyColumn(
                    state = listState,
                    reverseLayout = true,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    if (showRunning) {
                        item(key = "streaming") {
                            StreamingRow(
                                text = streaming,
                                status = status,
                                canOpenAgents = activeTaskId != null,
                                onOpenAgents = { activeTaskId?.let { sheetTaskId = it } }
                            )
                        }
                    }
                    items(reversed, key = { it.id }) { msg ->
                        MessageRow(
                            msg = msg,
                            isLast = !isRunning && msg.id == reversed.firstOrNull()?.id && msg.role == MessageRole.ASSISTANT,
                            hasAgentChat = msg.taskId != null && msg.taskId in agentTaskIds,
                            onOpenAgents = { msg.taskId?.let { sheetTaskId = it } },
                            onRegenerate = { viewModel.regenerate() }
                        )
                    }
                }
            }
        }

        InputBar(
            value = input,
            isRunning = isRunning,
            onChange = { viewModel.onInputChange(it) },
            onSend = { viewModel.sendMessage() },
            onStop = { viewModel.cancelTask() }
        )
    }

    sheetTaskId?.let { id ->
        AgentTranscriptSheet(taskId = id, viewModel = viewModel, onDismiss = { sheetTaskId = null })
    }
}

@Composable
private fun EmptyState(onPick: (String) -> Unit) {
    val suggestions = listOf(
        "Wyjaśnij mi prosto, jak działają korutyny w Kotlinie",
        "Napisz funkcję sortującą listę obiektów",
        "Porównaj sposoby przechowywania danych w Androidzie",
        "Zaplanuj mi tydzień nauki programowania"
    )
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("W czym mogę pomóc?", fontSize = 26.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(28.dp))
        suggestions.forEach { s ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SurfaceVariant)
                    .clickable { onPick(s) }
                    .padding(horizontal = 16.dp, vertical = 13.dp)
            ) {
                Text(s, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun MessageRow(
    msg: ChatMessage,
    isLast: Boolean,
    hasAgentChat: Boolean,
    onOpenAgents: () -> Unit,
    onRegenerate: () -> Unit
) {
    when (msg.role) {
        MessageRole.USER -> {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                SelectionContainer {
                    Text(
                        msg.content,
                        modifier = Modifier
                            .widthIn(max = 310.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(UserBubble)
                            .padding(horizontal = 16.dp, vertical = 11.dp),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }

        MessageRole.SYSTEM -> {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.errorContainer)
                    .padding(14.dp)
            ) {
                SelectionContainer { Text(msg.content, style = MaterialTheme.typography.bodyMedium) }
            }
        }

        else -> {
            val clipboard = LocalClipboardManager.current
            val context = LocalContext.current
            Column(Modifier.fillMaxWidth()) {
                SelectionContainer { MarkdownText(msg.content) }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                    ActionIcon(Icons.Filled.ContentCopy, "Kopiuj") { clipboard.setText(AnnotatedString(msg.content)) }
                    ActionIcon(Icons.Filled.Share, "Udostępnij") {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, msg.content)
                        }
                        context.startActivity(Intent.createChooser(send, null))
                    }
                    if (isLast) ActionIcon(Icons.Filled.Refresh, "Wygeneruj ponownie", onRegenerate)
                    if (hasAgentChat) {
                        Spacer(Modifier.width(6.dp))
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(SurfaceVariant)
                                .clickable(onClick = onOpenAgents)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Groups, contentDescription = null, modifier = Modifier.size(15.dp), tint = TextSecondary)
                            Spacer(Modifier.width(6.dp))
                            Text("Rozmowa agentów", fontSize = 12.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(38.dp)) {
        Icon(icon, contentDescription = desc, tint = TextSecondary, modifier = Modifier.size(19.dp))
    }
}

@Composable
private fun StreamingRow(text: String, status: String, canOpenAgents: Boolean, onOpenAgents: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        if (text.isNotBlank()) {
            MarkdownText(text)
        } else {
            val transition = rememberInfiniteTransition(label = "dot")
            val pulse by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
                label = "pulse"
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(13.dp)
                        .alpha(pulse)
                        .clip(CircleShape)
                        .background(Color(0xFFECECEC))
                )
                if (status.isNotBlank() && status != "Myślę…") {
                    Spacer(Modifier.width(10.dp))
                    Text(status, color = TextSecondary, fontSize = 14.sp)
                }
            }
            if (canOpenAgents) {
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(SurfaceVariant)
                        .clickable(onClick = onOpenAgents)
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Groups, contentDescription = null, modifier = Modifier.size(15.dp), tint = TextSecondary)
                    Spacer(Modifier.width(6.dp))
                    Text("Podejrzyj rozmowę agentów", fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun InputBar(
    value: String,
    isRunning: Boolean,
    onChange: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    val canSend = value.isNotBlank()
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(UserBubble)
                .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            BasicTextField(
                value = value,
                onValueChange = onChange,
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 8.dp),
                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, lineHeight = 22.sp),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.onSurface),
                maxLines = 8,
                decorationBox = { inner ->
                    Box {
                        if (value.isEmpty()) {
                            Text("Napisz wiadomość", color = TextSecondary, fontSize = 16.sp)
                        }
                        inner()
                    }
                }
            )
            Spacer(Modifier.width(8.dp))
            val active = isRunning || canSend
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (active) Color(0xFFECECEC) else Color(0xFF4A4A4A))
                    .clickable(enabled = active) { if (isRunning) onStop() else onSend() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isRunning) Icons.Filled.Stop else Icons.Filled.ArrowUpward,
                    contentDescription = if (isRunning) "Zatrzymaj" else "Wyślij",
                    tint = if (active) Color(0xFF171717) else Color(0xFF8A8A8A),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
