package com.aimasterpro.ui.screens.models

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aimasterpro.data.model.AgentRole
import com.aimasterpro.data.model.AiProviderConfig
import com.aimasterpro.data.model.ProviderType
import com.aimasterpro.domain.agent.AgentPrompts
import com.aimasterpro.domain.provider.ModelRecovery
import com.aimasterpro.domain.provider.ProviderTemplates
import com.aimasterpro.ui.MainViewModel
import com.aimasterpro.ui.components.BackButton
import com.aimasterpro.ui.theme.Accent
import com.aimasterpro.ui.theme.SuccessGreen
import com.aimasterpro.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val providers by viewModel.providers.collectAsState()
    val assignments by viewModel.roleAssignments.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var editProvider by remember { mutableStateOf<AiProviderConfig?>(null) }
    var deleteCandidate by remember { mutableStateOf<AiProviderConfig?>(null) }
    var repairInfo by remember { mutableStateOf<String?>(null) }
    var repairing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
            navigationIcon = { BackButton(onBack) },
            title = { Text("Modele AI", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )

            Text(
                "Dodaj tyle modeli, ile chcesz (Claude, OpenAI, Gemini, Groq…). Gwiazdka = MASTER, który rozmawia z Tobą. " +
                    "Pozostałym modelom przypisz role — zespół będzie współpracował w tle.",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Row(
                Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    enabled = !repairing,
                    onClick = {
                        scope.launch {
                            repairing = true
                            repairInfo = "Sprawdzam modele u dostawców…"
                            repairInfo = viewModel.repairModels()
                            repairing = false
                        }
                    }
                ) { Text("Napraw nazwy modeli") }
            }
            repairInfo?.let {
                Text(
                    it,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            LazyColumn(
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(providers, key = { it.id }) { provider ->
                    val roles = AgentRole.entries.filter { r ->
                        if (r == AgentRole.MASTER) provider.isDefault else assignments[r] == provider.id
                    }
                    ProviderCard(
                        provider = provider,
                        roles = roles,
                        onEdit = { editProvider = provider },
                        onToggle = { viewModel.setProviderEnabled(provider.id, it) },
                        onMaster = { viewModel.setDefaultProvider(provider.id) },
                        onDelete = { deleteCandidate = provider }
                    )
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = Accent,
            contentColor = androidx.compose.ui.graphics.Color.Black,
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Dodaj model") }
        )
    }

    if (showAdd || editProvider != null) {
        val editing = editProvider
        ProviderDialog(
            initial = editing,
            initialRoles = if (editing == null) emptySet() else AgentRole.entries.filter { r ->
                if (r == AgentRole.MASTER) editing.isDefault else assignments[r] == editing.id
            }.toSet(),
            viewModel = viewModel,
            onDismiss = {
                showAdd = false
                editProvider = null
            },
            onSave = { config, roles ->
                viewModel.saveProviderWithRoles(config, roles)
                showAdd = false
                editProvider = null
            }
        )
    }

    deleteCandidate?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("Usunąć model?") },
            text = { Text("„${p.name}” zostanie usunięty razem z zapisanym kluczem API. Tej operacji nie można cofnąć.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteProvider(p.id)
                    deleteCandidate = null
                }) { Text("Usuń", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteCandidate = null }) { Text("Anuluj") } }
        )
    }
}

private fun typeLabel(t: ProviderType) = when (t) {
    ProviderType.ANTHROPIC -> "Claude API"
    ProviderType.GEMINI -> "Gemini (OpenAI-compat.)"
    ProviderType.LOCAL_STUB -> "tryb lokalny"
    ProviderType.GROQ -> "Groq"
    ProviderType.OPENROUTER -> "OpenRouter"
    ProviderType.CUSTOM -> "własny endpoint"
    ProviderType.OPENAI_COMPATIBLE -> "OpenAI-compat."
}

@Composable
private fun ProviderCard(
    provider: AiProviderConfig,
    roles: List<AgentRole>,
    onEdit: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onMaster: () -> Unit,
    onDelete: () -> Unit
) {
    val isStub = provider.type == ProviderType.LOCAL_STUB
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onEdit,
        colors = CardDefaults.cardColors(
            containerColor = if (provider.isDefault)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
            else
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(provider.name, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${provider.modelName} • ${typeLabel(provider.type)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    val hasKey = provider.apiKey.isNotBlank()
                    if (!isStub) {
                        Text(
                            if (hasKey) "Klucz: zapisany" else if (provider.type == ProviderType.CUSTOM) "Klucz: opcjonalny" else "Brak klucza API",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (hasKey || provider.type == ProviderType.CUSTOM) SuccessGreen else MaterialTheme.colorScheme.error
                        )
                    }
                }
                if (!isStub) {
                    Switch(checked = provider.isEnabled, onCheckedChange = onToggle)
                    IconButton(onClick = onMaster) {
                        if (provider.isDefault) {
                            Icon(Icons.Filled.Star, contentDescription = "MASTER", tint = Accent)
                        } else {
                            Icon(Icons.Outlined.StarBorder, contentDescription = "Ustaw jako MASTER", tint = TextSecondary)
                        }
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, contentDescription = "Usuń", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
            if (roles.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Role: " + roles.joinToString(", ") { AgentPrompts.roleDisplayName(it) },
                    style = MaterialTheme.typography.labelMedium,
                    color = Accent
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun ProviderDialog(
    initial: AiProviderConfig?,
    initialRoles: Set<AgentRole>,
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
    onSave: (AiProviderConfig, Set<AgentRole>) -> Unit
) {
    val newId = remember { UUID.randomUUID().toString() }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: ProviderType.OPENAI_COMPATIBLE) }
    var baseUrl by remember { mutableStateOf(initial?.baseUrl ?: "") }
    var apiKey by remember { mutableStateOf(initial?.apiKey ?: "") }
    var modelName by remember { mutableStateOf(initial?.modelName ?: "") }
    var maxTokens by remember { mutableStateOf((initial?.maxTokens ?: 4096).toString()) }
    var enabled by remember { mutableStateOf(initial?.isEnabled ?: true) }
    var showKey by remember { mutableStateOf(false) }
    var roles by remember { mutableStateOf(initialRoles) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var models by remember { mutableStateOf<List<String>>(emptyList()) }
    var modelsMenu by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun currentConfig() = AiProviderConfig(
        id = initial?.id ?: newId,
        name = name.trim(),
        type = type,
        baseUrl = baseUrl.trim(),
        apiKey = apiKey.trim(),
        modelName = modelName.trim(),
        isEnabled = enabled,
        isDefault = initial?.isDefault ?: false,
        maxTokens = maxTokens.toIntOrNull()?.coerceIn(256, 64000) ?: 4096,
        temperature = initial?.temperature ?: 0.7f
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Dodaj model AI" else "Edytuj model") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (initial == null) {
                    Text("Wybierz dostawcę:", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ProviderTemplates.all.forEach { t ->
                            AssistChip(
                                onClick = {
                                    name = t.label
                                    type = t.type
                                    baseUrl = t.baseUrl
                                    modelName = t.model
                                    models = emptyList()
                                    info = null
                                },
                                label = { Text(t.label) }
                            )
                        }
                    }
                }

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nazwa") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Adres API (Base URL)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("Klucz API") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(
                                if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = "Pokaż/ukryj klucz"
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Box {
                    OutlinedTextField(
                        value = modelName,
                        onValueChange = { modelName = it },
                        label = { Text("Nazwa modelu") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            TextButton(
                                enabled = !busy,
                                onClick = {
                                    scope.launch {
                                        busy = true
                                        info = "Pobieram listę modeli…"
                                        val r = viewModel.fetchModels(currentConfig())
                                        r.onSuccess { list ->
                                            models = list
                                            if (list.isEmpty()) {
                                                info = "Dostawca nie zwrócił listy modeli."
                                            } else {
                                                val exists = list.any { m -> m.equals(modelName.trim(), ignoreCase = true) }
                                                val alt = if (exists) null else ModelRecovery.pickReplacement(modelName, list)
                                                if (alt != null) modelName = alt
                                                info = "Znaleziono modeli: ${list.size}" +
                                                    (if (alt != null) ". Ustawiono najbliższy istniejący: $alt" else "")
                                                modelsMenu = true
                                            }
                                        }
                                        r.onFailure { info = "❌ Nie udało się pobrać listy: ${it.message}" }
                                        busy = false
                                    }
                                }
                            ) { Text("Lista") }
                        }
                    )
                    DropdownMenu(expanded = modelsMenu, onDismissRequest = { modelsMenu = false }) {
                        models.take(300).forEach { m ->
                            DropdownMenuItem(text = { Text(m, fontSize = 13.sp) }, onClick = {
                                modelName = m
                                modelsMenu = false
                            })
                        }
                    }
                }

                OutlinedTextField(
                    value = maxTokens,
                    onValueChange = { maxTokens = it.filter { c -> c.isDigit() }.take(5) },
                    label = { Text("Maks. długość odpowiedzi (tokeny)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Model aktywny")
                }

                Text("Role tego modelu w zespole:", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AgentRole.entries.forEach { role ->
                        val lockedMaster = role == AgentRole.MASTER && initial?.isDefault == true
                        FilterChip(
                            selected = role in roles,
                            enabled = !lockedMaster,
                            onClick = { roles = if (role in roles) roles - role else roles + role },
                            label = { Text(AgentPrompts.roleDisplayName(role), fontSize = 12.sp) }
                        )
                    }
                }
                Text(
                    "MASTER rozmawia z Tobą i koordynuje. Rola bez przypisanego modelu pracuje na modelu MASTER.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                OutlinedButton(
                    enabled = !busy && baseUrl.isNotBlank() && modelName.isNotBlank(),
                    onClick = {
                        scope.launch {
                            busy = true
                            info = "Testuję połączenie…"
                            val err = viewModel.testProvider(currentConfig().copy(isEnabled = true))
                            info = if (err == null) "✅ Połączenie działa" else "❌ $err"
                            busy = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Testuj połączenie") }

                info?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (it.startsWith("❌")) MaterialTheme.colorScheme.error else if (it.startsWith("✅")) SuccessGreen else TextSecondary
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && baseUrl.isNotBlank() && modelName.isNotBlank(),
                onClick = { onSave(currentConfig(), roles) }
            ) { Text("Zapisz") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Anuluj") } }
    )
}
