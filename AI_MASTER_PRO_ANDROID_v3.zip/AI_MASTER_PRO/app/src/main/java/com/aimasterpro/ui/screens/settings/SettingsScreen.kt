package com.aimasterpro.ui.screens.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aimasterpro.data.model.AppSettings
import com.aimasterpro.ui.MainViewModel
import com.aimasterpro.ui.components.BackButton
import com.aimasterpro.ui.theme.Accent
import com.aimasterpro.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val settings by viewModel.settings.collectAsState()
    var maxIter by remember(settings) { mutableStateOf(settings.maxIterations.toString()) }
    var timeout by remember(settings) { mutableStateOf(settings.requestTimeoutSec.toString()) }
    var autoSave by remember(settings) { mutableStateOf(settings.autoSaveMemory) }
    var requireApproval by remember(settings) { mutableStateOf(settings.requireApprovalForDestructive) }
    val backupMessage by viewModel.backupMessage.collectAsState()
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) viewModel.exportBackup(uri) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) viewModel.importBackup(uri) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            navigationIcon = { BackButton(onBack) },
            title = { Text("Ustawienia", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Autonomia agentów", style = MaterialTheme.typography.titleMedium, color = Accent)

            OutlinedTextField(
                value = maxIter,
                onValueChange = { maxIter = it.filter { c -> c.isDigit() } },
                label = { Text("Maks. iteracji pipeline") },
                supportingText = { Text("Domyślnie 8. Zapobiega nieskończonym pętlom.") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = timeout,
                onValueChange = { timeout = it.filter { c -> c.isDigit() } },
                label = { Text("Timeout żądania (sekundy)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Wymagaj zgody na destrukcyjne operacje")
                    Text("Usuwanie danych, publikacja itp.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                Switch(checked = requireApproval, onCheckedChange = { requireApproval = it })
            }

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Auto-zapis do pamięci")
                    Text("Automatycznie zapisuj wyniki zadań", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                Switch(checked = autoSave, onCheckedChange = { autoSave = it })
            }

            Button(
                onClick = {
                    viewModel.updateSettings(
                        AppSettings(
                            maxIterations = maxIter.toIntOrNull() ?: 8,
                            requestTimeoutSec = timeout.toIntOrNull() ?: 90,
                            autoSaveMemory = autoSave,
                            requireApprovalForDestructive = requireApproval,
                            language = "pl",
                            defaultModelId = settings.defaultModelId
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) {
                Text("Zapisz ustawienia")
            }

            HorizontalDivider()

            Text("Kopia zapasowa", style = MaterialTheme.typography.titleMedium, color = Accent)
            Text(
                "Zapisz modele, klucze API, role i pamięć do pliku JSON — np. przed zmianą telefonu lub " +
                    "odinstalowaniem aplikacji. Plik zawiera klucze jawnym tekstem, przechowuj go bezpiecznie.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { exportLauncher.launch("ai_master_pro_backup.json") },
                    modifier = Modifier.weight(1f)
                ) { Text("Eksportuj") }
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                    modifier = Modifier.weight(1f)
                ) { Text("Importuj") }
            }
            backupMessage?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = Accent)
            }

            HorizontalDivider()

            Text("O aplikacji", style = MaterialTheme.typography.titleMedium, color = Accent)
            Text(
                "AI Master Pro v3.0.0\n" +
                        "Autonomiczny system wieloagentowy na Androida.\n\n" +
                        "Agenci: Master, Planista, Badacz, Programista, Audytor, Tester, Specjalista plików, Redaktor.\n\n" +
                        "Dane przechowywane lokalnie (Room).\n" +
                        "Brak obowiązkowego abonamentu — używasz własnych kluczy API.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}
