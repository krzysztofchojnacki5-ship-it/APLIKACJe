package com.aimasterpro.ui.screens.tasks

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aimasterpro.data.model.TaskEntity
import com.aimasterpro.data.model.TaskStatus
import com.aimasterpro.ui.MainViewModel
import com.aimasterpro.ui.components.BackButton
import com.aimasterpro.ui.components.AgentTranscriptSheet
import com.aimasterpro.ui.theme.Accent
import com.aimasterpro.ui.theme.SuccessGreen
import com.aimasterpro.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val tasks by viewModel.tasks.collectAsState()
    val isRunning by viewModel.isRunning.collectAsState()
    val agentTaskIds by viewModel.taskIdsWithAgentChat.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            navigationIcon = { BackButton(onBack) },
            title = { Text("Zadania", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        if (tasks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Brak zapisanych zadań.\nWyślij polecenie w czacie.", color = TextSecondary)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(tasks, key = { it.id }) { task ->
                    TaskCard(task, isRunning, task.id in agentTaskIds, viewModel)
                }
            }
        }
    }
}

@Composable
private fun TaskCard(task: TaskEntity, isRunning: Boolean, hasAgentChat: Boolean, viewModel: MainViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var showAgents by remember { mutableStateOf(false) }
    val status = try { TaskStatus.valueOf(task.status) } catch (_: Exception) { TaskStatus.PENDING }
    val dateFmt = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }

    val statusColor = when (status) {
        TaskStatus.COMPLETED -> SuccessGreen
        TaskStatus.FAILED, TaskStatus.CANCELLED -> MaterialTheme.colorScheme.error
        TaskStatus.RUNNING, TaskStatus.PLANNING -> Accent
        else -> TextSecondary
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = { expanded = !expanded },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(task.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        dateFmt.format(Date(task.createdAt)),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                Text(
                    status.name,
                    style = MaterialTheme.typography.labelMedium,
                    color = statusColor,
                    fontWeight = FontWeight.Bold
                )
            }

            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Text("Polecenie:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(task.userCommand, style = MaterialTheme.typography.bodySmall)
                if (task.result.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text("Wynik:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(task.result.take(500), style = MaterialTheme.typography.bodySmall)
                }
                if (task.errorLog.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("Błędy: ${task.errorLog.take(200)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (hasAgentChat) {
                        TextButton(onClick = { showAgents = true }) { Text("Rozmowa agentów") }
                    }
                    if (status in listOf(TaskStatus.PAUSED, TaskStatus.FAILED, TaskStatus.PENDING) && !isRunning) {
                        TextButton(onClick = { viewModel.resumeTask(task.id) }) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Wznów")
                        }
                    }
                    IconButton(onClick = { viewModel.deleteTask(task.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Usuń", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    if (showAgents) {
        AgentTranscriptSheet(taskId = task.id, viewModel = viewModel, onDismiss = { showAgents = false })
    }
}
