package com.aimasterpro.ui.screens.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aimasterpro.ui.MainViewModel
import com.aimasterpro.ui.theme.Accent
import com.aimasterpro.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsScreen(viewModel: MainViewModel) {
    val tools = listOf(
        Triple(Icons.Filled.Search, "Wyszukiwanie internetowe", "Planowane — wymaga konfiguracji zewnętrznego API (np. DuckDuckGo / SerpAPI). Agenci informują, gdy nie mają dostępu."),
        Triple(Icons.Filled.Description, "Praca z plikami", "Użytkownik może przekazać treść pliku w czacie. Pełna integracja z Storage Access Framework w kolejnej wersji."),
        Triple(Icons.Filled.Code, "Generowanie kodu", "Dostępne przez agenta Programisty. Wyniki pojawiają się w czacie i historii zadania."),
        Triple(Icons.Filled.FactCheck, "Audyt i testy", "Agenci Audytor i Tester automatycznie oceniają wyniki w pipeline."),
        Triple(Icons.Filled.History, "Historia zadań", "Pełna historia w zakładce Zadania z możliwością wznowienia."),
        Triple(Icons.Filled.Memory, "Pamięć długoterminowa", "Ręczne zapisywanie ważnych informacji. MASTER wykorzystuje je w kontekście.")
    )

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Narzędzia", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(tools.size) { idx ->
                val (icon, title, desc) = tools[idx]
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(title, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text(desc, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}
