package com.aimasterpro.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

// Paleta wzorowana na ChatGPT (tryb ciemny)
val Accent = Color(0xFF10A37F)          // zielony akcent (spinner, linki, aktywne elementy)
val AccentDark = Color(0xFF0D8A6B)
val BackgroundDark = Color(0xFF212121)  // tło czatu
val SidebarDark = Color(0xFF171717)     // panel boczny
val SurfaceDark = Color(0xFF212121)
val SurfaceVariant = Color(0xFF2F2F2F)  // bąbelek użytkownika, pole wpisywania, karty
val OnBackground = Color(0xFFECECEC)
val OnSurface = Color(0xFFECECEC)
val ErrorRed = Color(0xFFFF6B6B)
val SuccessGreen = Color(0xFF4CAF50)
val TextSecondary = Color(0xFFB4B4B4)
val Divider = Color(0xFF3A3A3A)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFECECEC),
    onPrimary = Color(0xFF171717),
    primaryContainer = AccentDark,
    onPrimaryContainer = Color.White,
    secondary = Accent,
    onSecondary = Color.White,
    background = BackgroundDark,
    onBackground = OnBackground,
    surface = SurfaceDark,
    onSurface = OnSurface,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = SurfaceVariant,
    surfaceContainerHigh = SurfaceVariant,
    surfaceContainerHighest = Color(0xFF383838),
    error = ErrorRed,
    onError = Color.White,
    errorContainer = Color(0xFF5A2A2A),
    outline = Divider,
    outlineVariant = Divider
)

private val AppTypography = Typography(
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 22.sp)
)

@Composable
fun AIMasterTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = AppTypography,
        content = content
    )
}
